package webdriver_1;

public class Robot
{
	void Walk()
	{
		System.out.println("walk expected");
		
	}
	void Run()
	{
		System.out.println("run expected");
		
	}

	public static void main(String[] args) 
	{
	  //calling instant method to static method,calling should be through object creation
      Robot obj=new Robot();
      obj.Run();
      
      //calling instant method
      new Robot().Walk();
      
      //calling instant method from another class
      new Alpha().jump();   //new classname().methodname();
      new Alpha().run();
      
      //calling static method from another class
      Alpha.move();        //classname.methodname();
      Alpha.walk();
		 
		
	}
	
	

}

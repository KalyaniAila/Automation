package webdriver_1;

public class Alpha
{

	    void jump()
		{
			System.out.println("jump executed");
		}
		
		void run() 
		{
			System.out.println("run executed");
		}
		
		static void walk()
		{
			System.out.println("walk executed");
		}
		
		static void move() 
		{
			System.out.println("move executed");
		}
		
		 public static void main(String[] args)
		 
		 {
			 //calling static method
			 walk();
			 move();
			 
			 //calling instant method to static method ...calling should be though object creation
		     Alpha obj=new Alpha();
		     obj.run();
		     new Alpha().jump();
		     
	
		}
		 
	
	
	
  	}

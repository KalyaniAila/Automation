package webdriver_1;

public class Fan 
{
	void ON()
	{
		System.out.println("ON");
	}
	static void OFF() 
	{
		System.out.println("OFF");
	}

	

	public static void main(String[] args)
	{
		//calling static method
		OFF();
		//calling instant method
      new Fan().ON();
		
	}

}

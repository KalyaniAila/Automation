package object_identification_dropdown;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class GetOption_Example
{

	public static void main(String[] args) 
	
	{
		System.setProperty("webdriver.chrome.driver","Drivers\\chromedriver.exe");
		 WebDriver driver=new ChromeDriver();
		 driver.get("https://v1.hdfcbank.com/branch-atm-locator/?lat=");
		 driver.manage().window().maximize();
		 
		Select State_Dropdown_selector= new Select(driver.findElement(By.id("customState")));
		int count=State_Dropdown_selector.getOptions().size();
		System.out.println("Number of available at dopdown is--->"+count);
		
	}

}

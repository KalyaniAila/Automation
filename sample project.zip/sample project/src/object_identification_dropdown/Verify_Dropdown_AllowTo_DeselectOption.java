package object_identification_dropdown;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Verify_Dropdown_AllowTo_DeselectOption 
{

	public static void main(String[] args) throws Exception
	{
		System.setProperty("webdriver.chrome.driver","Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
        driver.get("https://v1.hdfcbank.com/branch-atm-locator/?lat=");
        driver.manage().window().maximize();
        
      
        //Note:-This is sample program just for understanding
        //=>create multiple selection dropdown using javascript
    	
      ((JavascriptExecutor)driver).executeScript("document.getElementById('customState').setAttribute('multiple','multiple')");
		Thread.sleep(5000);   
        		
        
	}

}

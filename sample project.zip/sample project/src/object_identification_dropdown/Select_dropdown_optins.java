package object_identification_dropdown;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Select_dropdown_optins 
{

	public static void main(String[] args) throws Exception 
	{
	 System.setProperty("webdriver.chrome.driver","Drivers\\chromedriver.exe");
	 WebDriver driver=new ChromeDriver();
	 driver.get("https://v1.hdfcbank.com/branch-atm-locator/?lat=");
	 driver.manage().window().maximize();
		 
	 //selecting dropdown with visible name
	 new Select(driver.findElement(By.id("customState"))).selectByVisibleText("Delhi");
	 Thread.sleep(2000);
	 
	 //selecting dropdown with visible text
	 new Select(driver.findElement(By.id("customCity"))).selectByValue("new-delhi");
	 
	 //type text into editbox
	 driver.findElement(By.id("customLocality")).clear();
	 driver.findElement(By.id("customLocality")).sendKeys("ramnagar");
	 
	 //select checkbox(this method use to select and deselect options)
	 driver.findElement(By.id("amenity_category_order_types50")).click();
	 
	 //selecting dropdown with index number
	 new Select(driver.findElement(By.id("customRadius"))).selectByIndex(6);
	
		 

	}

}

package object_identification_dropdown;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Select_DropdownWithout_Select_Class
{

	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver","Drivers\\chromedriver.exe");
		 WebDriver driver=new ChromeDriver();
		 driver.get("https://v1.hdfcbank.com/branch-atm-locator/?lat=");
		 driver.manage().window().maximize();
		 
		 //Getoptions Xpath and perform click option
		 driver.findElement(By.xpath("//*[@id=\"amenity_category_order_types50\"]")).click();


	}

}


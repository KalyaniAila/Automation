package object_identification_dropdown;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class GetFirstSelectedOption
{

	public static void main(String[] args) 
	{
		 System.setProperty("webdriver.chrome.driver","Drivers\\chromedriver.exe");
		 WebDriver driver=new ChromeDriver();
		 driver.get("https://v1.hdfcbank.com/branch-atm-locator/?lat=");
		 driver.manage().window().maximize();
		 
		 Select State_Dropdown_selector=new Select(driver.findElement(By.id("customState")));
		State_Dropdown_selector.selectByIndex(5);
		 
		 String OptionText=State_Dropdown_selector.getFirstSelectedOption().getText();
			System.out.println(OptionText);
			
			
			/*
			 * GetFirstSelectedOption:-->
			 * 		Is a select class mehtod it return first Selected Option 
			 * 		as WebElement.
			 * 
			 * 		getText() is a WebElement Class Method it capture text available
			 * 		location
			 */
			Select State_Dropdown=new Select(driver.findElement(By.id("customCity")));
			State_Dropdown.selectByIndex(2);
			State_Dropdown.selectByValue("araria");
			
			String optiontext=State_Dropdown.getFirstSelectedOption().getText();
			System.out.println(optiontext);
	}
}
         
package object_identification_dropdown;

public class Verify_Dropdown_Multiple_SelectionType
{
  public static void main(String[] args) 
	{
		

	}

}

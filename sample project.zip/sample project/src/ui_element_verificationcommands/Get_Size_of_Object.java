package ui_element_verificationcommands;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Get_Size_of_Object {

	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
	      WebDriver driver=new ChromeDriver();
	      driver.get("https://www.spicejet.com/");
	      driver.manage().window().maximize();
	      
	      WebElement from_editbox=driver.findElement(By.xpath("//select[@id='ctl00_mainContent_ddl_originStation1']"));
	      
	      //get object height and width at runtime
	      Dimension obj_dimension=from_editbox.getSize();
	      
	      int obj_height=obj_dimension.getHeight();
	      System.out.println("object height is---->"+obj_height);
	      
	      int obj_width=obj_dimension.getWidth();
	      System.out.println("object width is---->"+obj_width);
	      
	      //verify object visibilty using height and width
	      if(obj_height >0) 
	      {
	    	  System.out.println("object visible at webpage");
	      }
	      else 
	      {
	    	  System.out.println("object hidden at webpage");
	      }
	      
	      if(obj_width>0) 
	      {
	    	  System.out.println("object visible at webpage");
	      }
	      else 
	      {
	    	  System.out.println("object hidden at webpage ");
	      }
	      
	               
             
	}

}

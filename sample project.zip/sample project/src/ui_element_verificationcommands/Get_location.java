package ui_element_verificationcommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Get_location
{

	public static void main(String[] args) 
	{
      System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
      WebDriver driver=new ChromeDriver();
      driver.get("https://www.spicejet.com/");
      driver.manage().window().maximize();
      
      WebElement Roundtrip_Label=driver.findElement(By.xpath("//label[.='Round Trip']"));
      
      //get object x and y coordinates
      int ObjX=Roundtrip_Label.getLocation().getX();
      int objY=Roundtrip_Label.getLocation().getY();
      System.out.println("object X coordinates are --->"+ObjX);
      System.out.println("object Y coordinates are ---->"+objY);
      
      //verify object visibility usng x and y coordinates
      if(ObjX>0) 
      {
    	  System.out.println("object is visible");
      }
      else 
      {
    	  System.out.println("object is hidden");
      }
      
      if(objY>0) 
      {
    	  System.out.println("object is visible");
      }
      else 
      {
    	  System.out.println("object is hidden");
      }
	}

}

    /*
     * for hidden object get location return zero coordinates
     */


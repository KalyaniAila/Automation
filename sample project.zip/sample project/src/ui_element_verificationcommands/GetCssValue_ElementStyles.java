package ui_element_verificationcommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetCssValue_ElementStyles {

	public static void main(String[] args) 
	{
		  System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
	      WebDriver driver=new ChromeDriver();
	      driver.get("https://www.spicejet.com/");
	      driver.manage().window().maximize();
	      
	      WebElement Roundtrip_Label=driver.findElement(By.xpath("//label[.='Round Trip']"));
	      
	      //selecting radio button using label
	      Roundtrip_Label.click();
	      
	      //retrieve label color
	      String Ele_color=Roundtrip_Label.getCssValue("color");
	      System.out.println("element color is---->"+Ele_color);
	      
	      //verifyexpected color presented at label
	      if(Ele_color.equals("rgba(255,0,0,1)"))
	      {
	    	  System.out.println("expected color presented");
	     }
	      else 
	      {
	    	  System.out.println("wrong color presented");
	      }
	      
	      //print text alignment
	     // String text_align=Roundtrip_Label.getCssValue("text_alignment");
	     // System.out.println(text_align);
	      System.out.println(Roundtrip_Label.getCssValue("text_align"));
	      System.out.println(Roundtrip_Label.getCssValue("font_size"));
	      
	  

	}

}

package pageobjects_Pagefactory_with_Global_constructor;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Cleartrip 
{
	WebDriver driver;

	public Cleartrip(WebDriver driver) 
	{
		this.driver=driver;
		//PageFactory.initElements(driver, this);
		
	}
	@FindBy(xpath="//input[contains(@name,'from_station')]") 
	public WebElement fromstation;
	
	@FindBy(xpath="//input[contains(@name,'to_station')]")  
	public WebElement Tostation;
	
	@FindBy(xpath="//select[contains(@name,'train[class]')]")    
	public List<WebElement> class_options;
	
	
	
	//reusable method for Train class dropdown selection
	public void Select_class(String classtype) 
	{
		for (WebElement eachoption : class_options) 
		{
			String optionname=eachoption.getText();
			if (optionname.equals(classtype)) 
			{
				eachoption.click();
				break;
				
			}
		}
	}
	
	@FindBy(xpath="//input[contains(@id,'dpt_date')]")
	public WebElement Date;
	
	@FindBy(xpath="//select[contains(@id,'train_adults')]")
	public List<WebElement> Adults_dropdown;
	
	@FindBy(xpath="//select[contains(@name,'children')]")
	public List<WebElement> children_dropdown;
	
	@FindBy(xpath="//select[contains(@id,'train_male_seniors')]")
	public List<WebElement> senior_men_dropdown;
	
	@FindBy(xpath="//select[contains(@id,'train_female_seniors')]")
	public List<WebElement> senior_women_dropdown;
	
	
	
	
	//Reusable method for all dropdown options to select
	public void Select_Adults(List<WebElement> options_element,String Exp_options) 
	{
	     for (WebElement eachoption : options_element) 
	     {
	    	 String optionname=eachoption.getText();
	    	 if (optionname.equals(Exp_options)) 
	    	 {
	    		 eachoption.click();
	    		 break;
				
			 }
			
		 }
	}

}

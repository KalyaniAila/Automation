package pageobjects_Pagefactory_with_Global_constructor;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Run_Cleartrip 
{

	public static void main(String[] args) throws Exception 
	{
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://www.cleartrip.com/trains");
		
		Cleartrip ct=new Cleartrip(driver);
		Thread.sleep(3000);
		
		ct.fromstation.sendKeys("Hyderabad Decan (HYB)");
		ct.Tostation.sendKeys("Mumbai Central (BCT)");
		//ct.Select_Adults(ct.class_options, "AC First Class (1A)");
		ct.Date.sendKeys("15/5/2021");
		
		ct.Select_Adults(ct.Adults_dropdown, "3");
		ct.Select_Adults(ct.children_dropdown,"2");
		ct.Select_Adults(ct.senior_men_dropdown, "2");
		ct.Select_Adults(ct.senior_women_dropdown, "2");
		
		

	}

}

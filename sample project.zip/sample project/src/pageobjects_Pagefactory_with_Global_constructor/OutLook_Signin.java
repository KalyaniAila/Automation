package pageobjects_Pagefactory_with_Global_constructor;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;

public class OutLook_Signin 
{
	
    WebDriver driver;
	public OutLook_Signin(WebDriver driver) 
	{
		this.driver=driver;
		
	}
	@FindBy(xpath=)

}

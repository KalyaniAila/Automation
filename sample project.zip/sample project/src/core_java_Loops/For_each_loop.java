package core_java_Loops;

public class For_each_loop 
{

	public static void main(String[] args) 
	{
		String tools[]= {"WD","RC","APPIUM","GRID","IDE"};
		
		for (String toolname : tools) 
		{
			System.out.println(toolname);
			
			if (tools.equals(toolname)) 
			{
				System.out.println();
			}
		
		}

	}

}

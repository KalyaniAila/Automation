package core_java_Loops;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class do_while_example 
{

	public static void main(String[] args) throws Exception 
	{
		System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		
		boolean flag=false;
		int count=0;
		do 
		{
			driver.get("https://www.facebook.com/r.php");
			try 
			{
				new WebDriverWait(driver, 10).until(ExpectedConditions.titleIs("Sign up for Facebook | Facebook"));
				flag=true;
				
			} catch (TimeoutException e)
			{
				flag=false;
			}
			
			count=count+1;
			if(count==5)
			{
				throw new Exception("Page laod failured, Tryed five times");
			}
			
	
			
			
		} while (flag==false);
	System.out.println("page load sucessful");

	}

}

package core_java_Loops;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Group_links 
{

	public static void main(String[] args) throws Exception 
	{
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com");
		driver.manage().window().maximize();
		
		String footer_links[]= {     "Sign Up",
				                     "Log In",
				                     "Messenger",
				                     "Facebook Lite",
				                     "Watch",
				                     "People",
				                     "Pages",
				                     "Page categories",
				                     "Places"
				
		                        };
		
		String Exp_title[]= {    "Sign up for Facebook | Facebook",
				                 "Log in to Facebook",
				                 "Messenger",
				                 "Facebook Lite APK for Android",
				                // "Facebook Lite APK for Android",
				                 "Facebook Watch",
				                 "Log in to Facebook",
				                 "Pages directory",
				                 "Page categories | Facebook",
				                 "Discover great places in every city | Facebook"
				
		                             };
		
		//interate for number of links
		for (int i = 0; i <footer_links.length; i++) 
		{
			//driver.findElement(By.linkText("footer_links[i]")).click();
			driver.findElement(By.linkText(footer_links[i])).click();

			Thread.sleep(2000);
			
			//vadilate expected title with actual title
			String Runtime_title=driver.getTitle();
			if (Runtime_title.equals(Exp_title[i])) 
			{
				System.out.println("testpass,title displayed--->"+Runtime_title);
			
			}
			else
			System.out.println("testfail,title displayed---->"+Runtime_title);
			driver.navigate().back();
			Thread.sleep(3000);
			
		}
		

	}

}

package core_java_Loops;

public class For_loop_example 
{

	public static void main(String[] args)
	{
		/*   print numbers from 1 to 10
		 *    for(variable;condition;increment/decrement) 
		 */
		
		for (int i = 0; i <10 ; i++) 
		{
			//It print value '1' 10 times
			//System.out.println("print value-->"+1);
			//it print 1to 9 values for '<' condition
			System.out.println(i);  
		}
		
		
		//this escape sequence and create new line at console
		System.out.println("\n");
		
		
		//print numbers from 10 to 1
		for (int i = 10; i >= 1; i--) 
		{
			System.out.println(i);
		}
		
		//this escape sequence and create new line at console
		System.out.println("\n");
		
		
		//conduct sum between 1 to 100
		int sum=0;
		for (int i = 0; i <=100 ; i++) 
		{
			 sum =sum +i;
		}
		System.out.println("total value sum is--->"+sum);
		
		System.out.println("\n");
		
		//How to reverse a string
		String toolname="WEBDRIVER";
		//Convert string characters into character array
		 char arr[]=toolname.toCharArray();
		 System.out.println("number of characters at string-->"+arr.length);
		 
		 
	}

}

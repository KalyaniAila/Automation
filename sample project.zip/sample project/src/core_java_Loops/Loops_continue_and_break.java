package core_java_Loops;

public class Loops_continue_and_break 
{

	public static void main(String[] args) 
	{
	   //Break loop when iteration reach to 4
		for (int i = 0; i < 10; i++) 
		{
			if(i==4)
			{
				break;   //This command break iteration
			}
			System.out.println(i);
		}
		
		
		
		//this escape sequence and create new line at console
		System.out.println("\n");
		
		//continue one iteration
		for (int i = 0; i <=10 ; i++) 
		{
			if(i==4 || i==7)
			{
				continue;        //this command skip one iteration
			}
			System.out.println(i);
		}

	}

}

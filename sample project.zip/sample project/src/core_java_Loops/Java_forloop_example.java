package core_java_Loops;

public class Java_forloop_example 
{

	public static void main(String[] args) 
	{
		int count=13,num1=2,num2=1;
		//System.out.println("count");
		
		for (int i = 1; i <=count; i++) 
		{
			System.out.println(num1);
			//System.out.println(num1+"");
			
			int sumofPrevTwo=num1+num2;
			num1=num2;
			num2=sumofPrevTwo;
			
		}

	}

}

package core_java_Loops;

public class Sumofarray 
{

	public static void main(String[] args) 
	{
       int num[]= {3,2,4,5,6,4,5,7,3,2,3,4,7,1,2,0,0,0};
       
       for (int i = 0; i < num.length; i++) 
       {
    	   
		
	   }

	}

}

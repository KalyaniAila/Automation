package pageobjects_Pagefactory;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

public class Run_FBHOME_using_pagefactory_class 
{

	public static void main(String[] args) throws Exception 
	{
		System.setProperty("webdriver.chrome.driver","Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://facebook.com");
		
		/*  Inorder to call @FindBy method from different class ,
		 *     we should create pagefactory class object
		 *  
		 */
		FB_HOME fb_page=PageFactory.initElements(driver, FB_HOME.class);
		Thread.sleep(3000);
		fb_page.user_login("Darshan", "Hello1234");
		
		//testcase with empty password
		Thread.sleep(5000);
		fb_page.Enter_email("kalyani");
		fb_page.Click_login_btn();
		
		//verify object is visible at webpage
		boolean flag=fb_page.login_email.isDisplayed();
		System.out.println("object visible status is---->"+flag);
		
		

	}

}

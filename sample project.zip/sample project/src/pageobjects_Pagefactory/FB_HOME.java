package pageobjects_Pagefactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class FB_HOME 
{
	@FindBy(id="email") 
	public WebElement login_email;
	
	//@FindBy(xpath="@FindBy(xpath = \"//input[@id='email']\")") 
	//public WebElement login_email;
	
	@FindBy(xpath="@FindBy(xpath = \"//input[@id='pass']\")")
	public WebElement login_password;
	
	@FindBy(xpath="@FindBy(xpath = \"//button[contains(@data-testid,'button')]\")")
	public WebElement login_submitt_btn;
	
	public void Enter_email(String uid) 
	{
		login_email.clear();
		login_email.sendKeys(uid);
	}
	
	public void Enter_password(String pwd) 
	{
		login_password.clear();
		login_password.sendKeys(pwd);
	}
	
	public void Click_login_btn() 
	{
		login_submitt_btn.click();
	}
	
	public void user_login(String username ,String password) 
	{
		Enter_email(username);
		Enter_password(password);
		Click_login_btn();
		
	   	
	}
	
	

}

package object_identification_editbox;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Auto_Complete_Editbox
{

	public static void main(String[] args) throws Exception 
	{
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://cleartrip.com");
		driver.manage().window().maximize();
		
		//select radio button(In webdriver click method wwe use to select radio button)
		driver.findElement(By.id("RoundTrip")).click();
        
		//
		driver.findElement(By.id("FromTag")).clear();
		driver.findElement(By.id("FromTag")).sendKeys("hyd");
        Thread.sleep(2000);//timeout load suggestion
		driver.findElement(By.linkText("Hyderabad, IN - Rajiv Gandhi International (HYD)")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.id("ToTag")).clear();
		driver.findElement(By.id("ToTag")).sendKeys("Mum");
		Thread.sleep(3000);
		driver.findElement(By.linkText("Mumbai, IN - Chatrapati Shivaji Airport (BOM)")).click();
		
		driver.findElement(By.id("DepartDate")).clear();
		driver.findElement(By.id("DepartDate")).sendKeys("Tue, 23 Mar, 2020");
		
	}

}

package object_identification_editbox;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class sendkeys_ex_editbox 
{

	public static void main(String[] args) 
	{
      System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
      WebDriver driver=new ChromeDriver();
      driver.get("https://www.facebook.com/r.php");
      driver.manage().window().maximize();
      
      
      driver.findElement(By.name("firstname")).sendKeys("ajay"+Keys.TAB+"krishna"+Keys.TAB+"ajaykrishna@gmail.com");
      driver.findElement(By.name("reg_email_confirmation__")).sendKeys("ajaykrishna@gmail.com");
      driver.findElement(By.name("reg_passwd__")).sendKeys("hello1234");
      
      //select dropdown option using sendkeys 
      driver.findElement(By.name("birthday_day")).sendKeys("25");
      
      //selecting ,month dropdown using keyboard chracters
      driver.findElement(By.name("birthday_month")).sendKeys("s");
      driver.findElement(By.name("birthday_month")).sendKeys(Keys.ARROW_DOWN,Keys.ARROW_DOWN);
      
      //select year dropdown using keyboard shortcuts
      driver.findElement(By.name("birthday_year")).sendKeys("2016");
      driver.findElement(By.name("birthday_year")).sendKeys(Keys.ARROW_DOWN,Keys.ARROW_UP);
      
      //select radio button using keyboard shortcut
      driver.findElement(By.xpath("//*[@id=\"u_0_4_A/\"]")).sendKeys(Keys.SPACE);
		
	}

}

package robot_window_interactions;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

public class Copy_String_Clipboard 
{

	public static void main(String[] args) throws InterruptedException, Exception 
	{
       String text="Tell us what kind of a job you are looking out for and stay updated with latest opportunities.";
       
       //copy string
       StringSelection stext=new StringSelection(text);
       
       //get system clipboard
       Clipboard clipboard=Toolkit.getDefaultToolkit().getSystemClipboard();
       
       //copy selected string to clipboard
       clipboard.setContents(stext, stext);
       
       
       //create notepad file at runtime
       Runtime.getRuntime().exec("notepad.exe");
       Thread.sleep(3000);
       
       //create object for class
       Robot robot=new Robot();
       robot.setAutoDelay(500);
       
       //paste clipboard text at notepad file
       robot.keyPress(KeyEvent.VK_CONTROL);
       robot.keyPress(KeyEvent.VK_V); 
       
       robot.keyPress(KeyEvent.VK_S);
       
       //copy text to clipboard
       String path="C:\\Users\\Pandu\\Documents\\gdkhs.txt";
       
       //copy string path
       StringSelection spath=new StringSelection(path);
       
       //copy selcted string path to clipboard
        clipboard.setContents(spath, spath);
        
       
       //paste text into window path location
       robot.keyPress(KeyEvent.VK_V);
       Thread.sleep(4000);
       robot.keyPress(KeyEvent.VK_ENTER);
       
      // release control
       robot.keyRelease(KeyEvent.VK_CONTROL);
       
       
       
       
       
       

       
       
       
       

	}

}

package robot_window_interactions;

import java.awt.Robot;
import java.awt.event.InputEvent;

public class Robot_mouse_syntax
{

	public static void main(String[] args) throws Exception 
	{
        //create object for robot framework
	     Robot robot=new Robot();
	     robot.setAutoDelay(500);
	     
	     //move cursor to required location
	     robot.mouseMove(100, 200);
	     
	     //mouse click
	     robot.mousePress(InputEvent.BUTTON1_MASK);    //left click
	     robot.mousePress(InputEvent.BUTTON2_MASK);    //middle click
         robot.mousePress(InputEvent.BUTTON3_MASK);    //right click
         
         //relase mouse
         robot.mouseRelease(InputEvent.BUTTON1_MASK);
         
         //scroll
         robot.mouseWheel(100);
	}

}

package robot_window_interactions;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;


public class robot_file 
{

	public static void main(String[] args) throws InterruptedException, IOException, Exception 
	{
		Runtime.getRuntime().exec("notepad.exe");        //IO exception   
		Thread.sleep(4000);                             //interupted exception 
		
		//create robot object
	    Robot robot=new Robot();           //exception
	    robot.setAutoDelay(5000);
	    
	    //type hello friends text into notepad file
	    robot.keyPress(KeyEvent.VK_H);
	    robot.keyPress(KeyEvent.VK_E);
	    robot.keyPress(KeyEvent.VK_L);
	    robot.keyPress(KeyEvent.VK_L);
	    robot.keyPress(KeyEvent.VK_O); 
	    
	    robot.keyPress(KeyEvent.VK_TAB);
	    
	    robot.keyPress(KeyEvent.VK_F);
	    robot.keyPress(KeyEvent.VK_R);
	    robot.keyPress(KeyEvent.VK_I);
	    robot.keyPress(KeyEvent.VK_E);
	    robot.keyPress(KeyEvent.VK_N);
	    robot.keyPress(KeyEvent.VK_D);
	    robot.keyPress(KeyEvent.VK_S);

	}

}

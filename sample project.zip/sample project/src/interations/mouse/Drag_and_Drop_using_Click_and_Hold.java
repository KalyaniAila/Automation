package interations.mouse;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;

public class Drag_and_Drop_using_Click_and_Hold
{
	WebDriver driver;
	String Driver_path="Drivers\\";
	String url="https://marcojakob.github.io/dart-dnd/basic/";

	
  @Test
  public void f() 
  {
	  WebElement doc1=driver.findElement(By.xpath("(//img[@class='document'])[1]"));
	  WebElement doc2=driver.findElement(By.xpath("(//img[@class='document'])[2]"));
	  WebElement doc3=driver.findElement(By.xpath("(//img[@class='document'])[3]"));
	  WebElement doc4=driver.findElement(By.xpath("(//img[@class='document'])[4]"));
	  
	  WebElement Trash_bin=driver.findElement(By.xpath("//div[@class='trash']"));
	  
	  //drag and drop object using click and hold
	  new Actions(driver).clickAndHold(doc1).moveToElement(Trash_bin).perform();
	  new Actions(driver).clickAndHold(doc2).moveToElement(Trash_bin).perform();
	  new Actions(driver).clickAndHold(doc3).moveToElement(Trash_bin).perform();
	  new Actions(driver).clickAndHold(doc4).moveToElement(Trash_bin).perform();
	  
	  boolean flag=Trash_bin.getAttribute("class").contains("full");
	  Assert.assertTrue(flag);
	  Reporter.log("Elemnet Drag to target successfull");
	  
  }
  
  
  @BeforeClass
  public void beforeClass() 
  {
	  System.setProperty("webdriver.chrome.driver", Driver_path+"chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.get(url);
	  driver.manage().window().maximize();
	  
  
	  
  }

  @AfterClass
  public void afterClass() throws Exception 
  {
	  Thread.sleep(4000);
	  driver.close();
	  
  }

}

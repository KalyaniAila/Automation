package interations.mouse;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;

public class Mouse_over
{
	WebDriver Driver;
	String Driver_path="Drivers\\";
	String url="http://naukri.com";
	
	
	
  @Test
  public void Testcase1() 
  {
	  WebElement tools_link=Driver.findElement(By.xpath("(//div[@class='mTxt'])[4]"));
	  
	  //perform mouseover action on tools main menu
	  new Actions(Driver).moveToElement(tools_link).perform();
	  
	  WebElement skills_trends_menu=Driver.findElement(By.xpath("//a[@title='Skills Trends']"));
	  
	  //perform mouseover action on skills tends menu
	  new Actions(Driver).moveToElement(skills_trends_menu).perform();
  }
  
  
  @BeforeClass
  public void beforeClass() 
  {
	  System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
	  Driver=new ChromeDriver();
	  Driver.get(url);
	  Driver.manage().window().maximize();
	  
  }

  @AfterClass
  public void afterClass() throws Exception
  {
	  Thread.sleep(3000);
	  Driver.close();
	  
  }

}

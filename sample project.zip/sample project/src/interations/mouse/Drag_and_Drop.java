package interations.mouse;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;

public class Drag_and_Drop
{
	WebDriver driver;
	String Driver_path="C:\\selenium java\\sample project\\Drivers\\";
	String url="https://marcojakob.github.io/dart-dnd/basic/";
	
	
	@Test
  public void Testcase()
  {
	  WebElement doc1=driver.findElement(By.xpath("(//img[@class='document'])[1]"));
	  WebElement doc2=driver.findElement(By.xpath("(//img[@class='document'])[2]"));
	  WebElement doc3=driver.findElement(By.xpath("(//img[@class='document'])[3]"));
	  WebElement doc4=driver.findElement(By.xpath("(//img[@class='document'])[4]"));
	  
	  WebElement Trash_bin=driver.findElement(By.xpath("//div[@class='trash']"));
	  
	  //using direct method target drag object into bin 
	  new Actions(driver).dragAndDrop(doc1, Trash_bin).perform();
	  new Actions(driver).dragAndDrop(doc2, Trash_bin).perform();
	  new Actions(driver).dragAndDrop(doc3, Trash_bin).perform();
	  new Actions(driver).dragAndDrop(doc4, Trash_bin).perform();
	  
	  boolean flag=Trash_bin.getAttribute("class").contains("full");
	  Assert.assertTrue(flag);
	  Reporter.log("Elemnet Drag to target successfull");

	  
 }
  
  
  @BeforeClass
  public void beforeClass() 
  {
	  System.setProperty("webdriver.chrome.driver", Driver_path+"chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.get(url);
	  driver.manage().window().maximize();
	  
  }

  @AfterClass
  public void afterClass() throws Exception 
  {
	  Thread.sleep(5000);
	  driver.close();
  }

}


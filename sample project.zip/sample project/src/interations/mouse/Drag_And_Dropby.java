package interations.mouse;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class Drag_And_Dropby
{
	WebDriver driver;
	String driver_path="Drivers\\";
	String url="https://www.hdfcbank.com/personal/tools-and-calculators/personal-loan-calculator";
	
	
	
  @Test
  public void f()
  {
  }
  
  
  @BeforeClass
  public void beforeClass() 
  {
	  System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.get(url);
	  driver.manage().window().maximize();
	  
  }

  @AfterClass
  public void afterClass() 
  {
  }

}

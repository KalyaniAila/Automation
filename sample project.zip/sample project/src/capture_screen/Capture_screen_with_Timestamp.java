package capture_screen;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class Capture_screen_with_Timestamp
{

	public static void main(String[] args) throws IOException, Exception 
	{
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		Thread.sleep(2000);
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.naukri.com/free-job-alerts");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		
		//get default system time
		Date d=new Date();
		//Crate simple date format
		DateFormat df=new SimpleDateFormat("yyyy-MMM-dd hh-mm-ss");
		//Convert Default date using dateformatter
		String time=df.format(d);
			
		//capture screen at automation browser and convert it into file format
		File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		
		//create project under folder
		FileHandler.createDir(new File("Screens"));
		
		//copy file to folder
		FileHandler.copy(src, new File("Screens\\Image"+time+".Png"));
		

	}

}



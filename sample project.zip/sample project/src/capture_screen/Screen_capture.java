package capture_screen;

import java.io.File;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class Screen_capture 
{

	public static void main(String[] args) throws Exception
	{
		System.setProperty("webdriver.chrome.drver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.naukri.com/free-job-alerts");
		driver.manage().window().maximize();
		
		//capture screen at automation browser and convert it into file format
		File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		
		//create folder under project
		FileHandler.createDir(new File("Screens"));       //ERROR THORWS EXCEPTOM
		
		//copy file to folder
		FileHandler.copy(src, new File("Screens\\Image.Png"));

	}

}


          /* Disadvantages:-
           *    capture only visible interface of screen
           *    cannot capture screen when alert presented
           *    every time code executed it override image
           *    
           *    Note:--In selenium 4 beta version it capture screen of entire page
           * 
           * 
           * 
           */
          





package java_script_executor;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class Javascript_runtime_Changes 
{
	WebDriver driver;
	  String Driver_path="Drivers\\";
	  String url="https://www.facebook.com/";
	  
  @Test
  public void testcase() throws Exception 
  {
	  JavascriptExecutor js=((JavascriptExecutor)driver);
	  //identify webelement
	  WebElement Email_editbox=driver.findElement(By.xpath("//input[@id='email']"));
	  Thread.sleep(5000);
	  
	  //Disable element
	  js.executeScript("arguments[0].disabled='true'",Email_editbox );
	  Thread.sleep(5000);
	  
	  //Enable element
	  js.executeScript("arguments[0].disabled='false'",Email_editbox);
	  Thread.sleep(5000);
	  
	  //Hide element from webpage
	  js.executeScript("arguments[0].style.visibility='hidden'",Email_editbox );
	  Thread.sleep(5000);
	  
	  //visibility of elment
	  js.executeScript("arguments[0].style.visibility='visible'",Email_editbox );
	  Thread.sleep(5000);
	  
	  //set readonly mode
	  js.executeScript("arguments[0].setAttribute('readonly','readonly')", Email_editbox);
	  Thread.sleep(5000);
	  
	  //set writable mode
	  js.executeScript("arguments[0].removeAttribute('readonly','readonly')", Email_editbox);
	  Thread.sleep(5000);
	 
	  
  }
  
  @BeforeClass
  public void beforeClass() 
  {
	  System.setProperty("webdriver.chrome.driver", Driver_path+"chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.get(url);
	  driver.manage().window().maximize();
  }

  @AfterClass
  public void afterClass() throws Exception 
  {
	  Thread.sleep(3000);
  }

}

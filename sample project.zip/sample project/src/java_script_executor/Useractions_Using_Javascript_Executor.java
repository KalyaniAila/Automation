package java_script_executor;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class Useractions_Using_Javascript_Executor
{
	WebDriver driver;
	String Driver_path="Drivers\\";
	String url="http://facebook.com";
	
	
  @Test
  public void Testcase() throws Exception 
  {
	  //Enable javascript on Automation browser
	  JavascriptExecutor js=((JavascriptExecutor)driver);
	  
	  //Type text into editbox using Javascript
	  js.executeScript("document.getElementById('email').value='darshan@gmail.com'");
	  Thread.sleep(4000);
	  
	  js.executeScript("document.getElementById('passContainer').value='hello1234'");
	  
	  //Javascript object identification using xpath
	 // js.executeScript("document.getElementById('u_0_d_Dj').click()");
	  WebElement login_button=driver.findElement(By.xpath("//button[@name='login']"));
	  js.executeScript("argument[0]",login_button);
	   
	  
  }
  
  
  
  @BeforeClass
  public void beforeClass() 
  {
	  System.setProperty("webdriver.chrome.driver", Driver_path+"chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.get(url);
	  driver.manage().window().maximize();
  }
  
  

  @AfterClass
  public void afterClass() throws Exception
  {
	  Thread.sleep(3000);
  }

}

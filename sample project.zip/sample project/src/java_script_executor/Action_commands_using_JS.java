package java_script_executor;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class Action_commands_using_JS 
{
	WebDriver driver;
	String Driver_path="Drivers\\";
	String url="https://www.facebook.com/r.php";
	
  @Test
  public void testcase() throws Exception 
  {
	  //Enable javascript to automation browser
	  JavascriptExecutor js=((JavascriptExecutor)driver);
	  
	  //identify element
	  WebElement firstname=driver.findElement(By.xpath("//input[@name='firstname']"));
	  //type text into editbox using javascript
	  js.executeScript("arguments[0].value='newuser'", firstname);
	  
	  //type text into editbox using javascript
	  WebElement lastname=driver.findElement(By.xpath("//input[@name='lastname']"));
	  js.executeScript("arguments[0].value='webdriver'",lastname );
	  Thread.sleep(3000);
	  
	  //select dropdown with value property using javascript
	  WebElement day_dropdown=driver.findElement(By.xpath("//select[@id='day']"));
	  js.executeScript("arguments[0].value='5'",day_dropdown );
	  Thread.sleep(3000);
	  
	  //select dropdown with index property using javascript
	 // js.executeScript("document.getElementById('month').value='Feb'");
	  js.executeScript("document.getElementById('month').selectedIndex='Feb'");
	  Thread.sleep(3000);
	  
	  //select radio button using javascript
	  WebElement female_radio_btn=driver.findElement(By.xpath("//input[@value='1']"));
	  js.executeScript("arguments[0].click", female_radio_btn);
	  Thread.sleep(3000);
	  
	  WebElement male_radio_btn=driver.findElement(By.xpath("//input[@value='2']"));
	  js.executeScript("arguments[0].checked='checked'", male_radio_btn);

	  
	  
	  
  }
 
  @BeforeClass
  public void beforeClass() 
  {
	  System.setProperty("webdriver.chrome.driver", Driver_path+"chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.get(url);
	  driver.manage().window().maximize();
  }

  @AfterClass
  public void afterClass() throws Exception 
  {
	  Thread.sleep(5000);
	  driver.close();
  }

}

package java_script_executor;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class dropdown_selection_using_javascript 
{
	WebDriver driver;
	String Driver_path="Drivers\\";
	String url="https://www.facebook.com/r.php";
	
	
  @Test
  public void testcase() 
  {
	  //enable javascript on automation browser
	  JavascriptExecutor js=((JavascriptExecutor)driver);
	  
	  //select dropdown selection option using javascript
	  js.executeScript("document.getElementById('day').value='6'");
	  js.executeScript("document.getElementById('month').selectindex='4'");
	  
  }
  
  
  @BeforeClass
  public void beforeClass() 
  {
	  System.setProperty("webdriver.chrome.driver", Driver_path+"chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.get(url);
	  driver.manage().window().maximize();
  }
  
  

  @AfterClass
  public void afterClass() throws Exception
  {
	  Thread.sleep(4000);
	  driver.close();
  }

}

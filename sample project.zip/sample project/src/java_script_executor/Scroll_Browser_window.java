package java_script_executor;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class Scroll_Browser_window 
{
	WebDriver driver;
	String Driver_path="Drivers\\";
	String url="https://www.naukri.com";
	
  @Test
  public void testcase() 
  {
	  //enable javascript into automation browser
	  JavascriptExecutor js=((JavascriptExecutor)driver);
	  
	  //scroll window down vertically
	  js.executeScript("window.scrollBy(0,1000)");
	  js.executeScript("window.scrollBy(0,-500)");
	  
	  /*   
	   * window.scrollBy(0,100)   //scroll 100px  to downwonds
	   * window.scrollBy(100,0)   //scroll 100px to right
	   * 
	   */
	  
	    
	  
  }
  
  @BeforeClass
  public void beforeClass() 
  {
	  System.setProperty("webdriver.chrome.driver", Driver_path+"chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.get(url);
	  driver.manage().window().maximize();
  }
  @AfterClass
  public void afterClass() throws Exception
  {
	  Thread.sleep(4000);
	  driver.close();
	  
   }
	  
  }
  

  

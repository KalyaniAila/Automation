package java_script_executor;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class Asynchronized_timeout_to_manage 
{
	WebDriver driver;
	String Driver_path="Drivers\\";
	String url="https://www.facebook.com/";
	
  @Test
  public void f() 
  {
	  JavascriptExecutor js=((JavascriptExecutor)driver);
	  //identify element
	  WebElement messenger=driver.findElement(By.xpath("//a[@title='Take a look at Messenger.']"));
	  messenger.click();
	  
	  long start=System.currentTimeMillis();
	  
	  //manage timeout all asychronized objects to load webpage
	  js.executeAsyncScript("window.setTimeout(arguments[arguments.length-1]),500");
	  
	  long End=System.currentTimeMillis();
	  
	  System.out.println(End-start+"---->Elapsed time is");
  }
  
  
  @BeforeClass
  public void beforeClass() 
  {
	  System.setProperty("webdriver.chrome.driver", Driver_path+"chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.get(url);
	  driver.manage().window().maximize();
  }

  @AfterClass
  public void afterClass() throws Exception 
  {
	  Thread.sleep(4000);
	  driver.close();
  }

}

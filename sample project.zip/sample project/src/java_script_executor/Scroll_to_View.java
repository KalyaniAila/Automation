package java_script_executor;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class Scroll_to_View 
{
	WebDriver driver;
	String Driver_path="Drivers\\";
	String url="https://www.facebook.com/r.php";
	
	
  @Test
  public void testcase() 
  {
	  //Enable javascript in to automation browser
	  JavascriptExecutor js=((JavascriptExecutor)driver);
	  WebElement Month_dropdown=driver.findElement(By.xpath("//select[@id='month']"));
	  js.executeScript("arguments[0].scrollIntoView()",Month_dropdown);
	  
	//  ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView()",Month_dropdown);
		
	  
  }
  
  @BeforeClass
  public void beforeClass()
  {
	  System.setProperty("webdriver.chrome.driver", Driver_path+"chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.get(url);
	  driver.manage().window().maximize();
  }

  @AfterClass
  public void afterClass() throws Exception 
  {
	  Thread.sleep(3000);
	  driver.close();
  }

}

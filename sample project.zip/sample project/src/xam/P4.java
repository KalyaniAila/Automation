package xam;

public class P4 
{
	class Base {
	    public void foo() { System.out.println("Base"); }
	}	

	class Derived extends Base {
	    private void foo() { System.out.println("Derived"); } 
	}

	public class Main {
	    public static void main(String args[]) {
	        Base b = new Derived();
	b.foo();
	    }
	} 


}

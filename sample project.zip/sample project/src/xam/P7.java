package xam;

public class P7 

{
	// Note static keyword after import.
	import static java.lang.System.*;

	class StaticImportDemo
	{
	   public static void main(String args[])
	   {      
	out.println("Qapitol QA");
	   }
	}


}

package xam;

public class P1 
{
	class  Test
	{
		  int i;
	} 
		 class  Main
		{
		 // public static void m (String args[]) 
			 public static void main(String args[])
			 
		  { 
		      Test t = new Test(); 
		System.out.println(t.i);
		   } 
		}


}

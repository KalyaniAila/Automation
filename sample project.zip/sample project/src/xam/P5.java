package xam;

public class P5 
{
	class Main {
	    public static void main(String args[]) {   
	System.out.println(fun());
	    } 	

	    int fun()
	    {
	      return 20;
	    }
	}


}

package xam;

public class P2 
{
	 class Test 
	 {
		  int i;
		} 	
		class Main 
		{
		   public static void main(String args[]) 
		   { 
		     Test t;
		System.out.println(t.i);
		}  
		   
		}
}



package xam;

public class P6 
{   
	public static void main(String args[]) { 
	   String x = null;
	   giveMeAString(x);
	   System.out.println(x);
	       } 	
	       static void giveMeAString(String y) 
	       { 
	          y = "Qapitol QA";
	       } 
	   }



}
package chrome_options;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Window_set_size 
{

	public static void main(String[] args) throws Exception 
	{
		ChromeOptions options=new ChromeOptions();
		options.addArguments("window_size=400,300");
		
		System.setProperty("webdriver.chrome.driver","Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver(options);
		driver.get("http://facebook.com");
		System.out.println("defalut window is opened");
		Thread.sleep(3000);

		driver.manage().window().setSize(new Dimension(600, 500));
		System.out.println("site is ready to use");

	}

}

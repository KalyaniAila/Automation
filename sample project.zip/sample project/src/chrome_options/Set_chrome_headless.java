package chrome_options;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterClass;

public class Set_chrome_headless 
{
	WebDriver driver;
	String Driver_path="Drivers\\";
	String url="http://facebook.com";
	
  @Test
  public void f() 
  {
	  ChromeOptions options=new ChromeOptions();
	  //options.addArguments("--headless");
	  options.setHeadless(true);
	  
	  
  }
  
  @BeforeClass
  public void beforeClass() 
  {
	  System.setProperty("webdriver.chrome.driver", Driver_path+"chromedriver.exe");
	  driver=new ChromeDriver(options);
	  driver.get(url);
	  
	  
  }

  @AfterClass
  public void afterClass() 
  {
	  driver.close();
  }

}

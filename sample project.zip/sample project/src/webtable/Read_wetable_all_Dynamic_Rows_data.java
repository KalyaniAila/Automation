package webtable;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class Read_wetable_all_Dynamic_Rows_data 
{
	WebDriver driver;
	String Driver_path="Drivers\\";
	String url="";
	
  @Test
  public void f() 
  {
	 // FAQ:- Read data from dynamic row based of reference text
	  
	  //target table
	  WebElement table=driver.findElement(By.id("tblMarketToday"));
	  
	  //find list of dynamic rows available at table
	  List<WebElement> Rows =table.findElements(By.tagName("tr"));
	  Rows.remove(0);
  }
  
  
  @BeforeClass
  public void beforeClass() 
  {
	  System.setProperty("webdriver.chrome.driver", Driver_path+"chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.get(url);
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	  driver.manage().window().maximize();
  }

  @AfterClass
  public void afterClass() 
  {
	  driver.close();
  }

}

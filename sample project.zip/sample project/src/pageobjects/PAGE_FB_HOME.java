package pageobjects;

import org.openqa.selenium.By;

public class PAGE_FB_HOME 
{
	/*   public modifier allowed variable to access outside package as well
	 * 
	 *   static is useful to get object from outside class without object creation
	 *       only by using classname
	 * 
	 */
   public static By login_email_txt=By.xpath("//input[contains(@id,'email')]");
   public static By login_password_txt=By.xpath("//input[contains(@data-testid,'royal_pass')]");
   public static By login_login_btn=By.xpath("//button[contains(@data-testid,'button')]");
   public static By forgot_password_link=By.xpath("//a[contains(.,'Forgotten password?')]");
   
   //input data
   public static String page_url="http://facebook.com";
   public static String exp_title="Facebook � log in or sign up";
   public static String username="qadarshan";
   public static String password="hello@123";
   public static String login_Error_msg="";
   

}

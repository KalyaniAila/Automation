package pageobjects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Run_FB_HOME_Objects 
{

	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver","Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get(PAGE_FB_HOME.page_url);
		
		if (driver.getTitle().equals(PAGE_FB_HOME.exp_title)) 
		{
			WebElement UID_element=driver.findElement(PAGE_FB_HOME.login_email_txt);
			UID_element.clear();
			UID_element.sendKeys(PAGE_FB_HOME.username);
			
			WebElement PWD_element=driver.findElement(PAGE_FB_HOME.login_password_txt);
			PWD_element.clear();
			PWD_element.sendKeys(PAGE_FB_HOME.password);
			
		}
		else
			System.out.println("wrong title presented for fb homepage");
		

	}

}

package core_java_Arrays;

public class Static_Array_double_Dimension 
{

	public static void main(String[] args) 
	{
		
		/*  
		 * Syntax:-
		 *       new String[rows][cells/columns]
		 *    It represent in tabluar format
		 */
		
		String data[][]=new String[3][2];
		
		//first row data
		data[0][0]="userA";
		data[0][1]="PwdA";
		
		//second row data
		data[1][0]="userB";
		data[1][1]="pwdB";
		
		//third row data
		data[2][0]="userC";
		data[2][1]="pwdC";
		
        //print pwdB
		System.out.println(data[1][1]);
		System.out.println(data[0][1]);
		
		//Get size of array
		System.out.println("number of rows data available--->"+data.length);   // o/p:-3
		
		
		
	}

}

package core_java_Arrays;

public class Static_Array_Single_Dimension 
{

	public static void main(String[] args) 
	{
		
		//in single dimension array define fixed boundaries[5]
	    String arrayname[]=new String[5];
	    
	    arrayname[0]="apple";
	    arrayname[1]="LG";
	    arrayname[2]="Sumsang";
	    arrayname[3]="Vivo";
	    arrayname[4]="Oppo";
	    
	    /*
	     * If boundary value exceeded it throws an exception "OutOfBoundaryException"
	     */
	   // System.out.println(arrayname[5]);
	    
	    //print array value
	    System.out.println(arrayname[3]);
	    
	    //get size of array 
	    System.out.println("number of boundaries available--->"+arrayname.length);
	    
	    String num[]=new String[3];
	    
	    num[0]="100";
	    num[1]="200";
	    num[2]="300";
	    
	    //print array value
	    System.out.println(num[2]);
	    
	    //get size of array
	    System.out.println(num.length);
	    

	}

}

package core_java_Arrays;

public class Runtime_array_sinle_dimension 
{

	public static void main(String[] args)
	{
		
		/*
		 * No need to declare boundaries,it arrange data values based on user assigned data.
		 * 
		 * Index value starts from "ZERO"
		 */
		
		String toolsmoblies[]= {"IDE","RC","WD","Appium","Grid","Vivo","Samsung","Oppo"};
		
		//Print WD name
		System.out.println("get 4th index number-->"+toolsmoblies[4]);
		System.out.println("get 6th index number--->"+toolsmoblies[6]);
		
		//get size of array
		System.out.println("count is--->"+toolsmoblies.length);
		
		int num[]= {100,200,300,400,500,600,700,800};
		
		//print index 5
		System.out.println(num[5]);
		System.out.println(num[7]);
		
		//get size of array
		System.out.println("index count--->"+num.length);
		

	}

}

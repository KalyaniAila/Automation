package core_java_Arrays;

public class Runtime_array_double_dimension 
{

	public static void main(String[] args) 
	{
		
		String userdata[][]= {    
				                  {"arun","6098754325"},
				                  {"meena","7654389056"},
				                  {"deepak","7623109874"},
				                  {"mani", "9805312567"}    
				                                             };
		
		//print 
		System.out.println(userdata[2][0]);
		System.out.println(userdata[1][1]);
		
		//combination values to store [strings,numbers,decimals--etc]
		Object product_info[][]={
				                    {"Iphone",100123,35000.00},
				                     {"Vivo",100124,36000.00},
		                                                             };
		System.out.println(product_info[0][0]);
		
		/*
		 *    out of boundary exception
		 */
		//System.out.println(product_info[2][1]);
		
		System.out.println(product_info[0][1]);
		System.out.println(product_info[1][2]);
		
		System.out.println(product_info[1][1].getClass());

	}

}

package iterations.Mouse;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Mouse_over 
{

	public static void main(String[] args) 
	{
       System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
       WebDriver driver=new ChromeDriver();
       driver.get("http://naukri.com");
       driver.manage().window().maximize();
       
       WebElement Tools_mainmenu=driver.findElement(By.xpath("(//div[@class='mTxt'])[4]"));
       Tools_mainmenu.click();

	}

}

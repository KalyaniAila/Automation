package interactions.keyboard;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;

public class keysdown_and_keysup_action 
{
	WebDriver driver;
	String Driver_path="Drivers\\";
	String url="https://jqueryui.com/selectable/";
	
	
  @Test
  public void testcase()
  {
	  WebElement demoframe=driver.findElement(By.className("demo-frame"));
	  driver.switchTo().frame(demoframe);
	  
	  //press keydown control key
	  new Actions(driver).keyDown(Keys.CONTROL).perform();
	  
	  driver.findElement(By.xpath("//li[contains(.,'Item 1')]")).click();
	  driver.findElement(By.xpath("//li[contains(.,'Item 3')]")).click();
	  driver.findElement(By.xpath("//li[contains(.,'Item 7')]")).click();
	  
	  //release control key
	  new Actions(driver).keyUp(Keys.CONTROL).perform();
  }
  
  
  @BeforeClass
  public void beforeClass() 
  {
	  System.setProperty("webdriver.chrome.driver", Driver_path+"chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.get(url);
	  driver.manage().window().maximize();
  }

  
  
  
  @AfterClass
  public void afterClass() throws Exception
  {
	  Thread.sleep(3000);
	  driver.close();
  }

}

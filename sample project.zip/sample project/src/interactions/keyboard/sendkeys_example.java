package interactions.keyboard;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;

public class sendkeys_example 
{
	WebDriver driver;
	String Driver_path="Drivers\\";
	String url="https://www.naukri.com/free-job-alerts";
	
	
  @Test
  public void testcase()
  {
	  WebElement keyskills=driver.findElement(By.xpath("//input[@id='Sug_kwdsugg']"));
	  new Actions(driver).sendKeys(keyskills,"manual")
	  .pause(3000)
	  .sendKeys(Keys.ARROW_DOWN)
	  .pause(3000)
	  .sendKeys(Keys.ENTER)
	  .perform();
	  
	  WebElement Location=driver.findElement(By.xpath("//input[@name='location']"));
	  new Actions(driver).sendKeys(Location,"HYD")
	  .pause(5000)
	  .sendKeys(Keys.ARROW_DOWN)
	  .pause(2000)
	  .sendKeys(Keys.ENTER)
	  .perform();
  }
  
  
  
  @BeforeClass
  public void beforeClass()
  {
	  System.setProperty("webdriver.chrome.driver", Driver_path+"chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.get(url);
	  driver.manage().window().maximize();
  }

  
  
  @AfterClass
  public void afterClass() throws Exception 
  {
	  Thread.sleep(3000);
	  driver.close();
  }

}

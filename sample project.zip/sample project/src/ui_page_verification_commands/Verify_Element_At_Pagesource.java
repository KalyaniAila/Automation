package ui_page_verification_commands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Verify_Element_At_Pagesource
{

	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://facebook.com");
		driver.manage().window().maximize();
		
		//get page source
		String Pagesource=driver.getPageSource();
		
		//verify expected element id presented at page souce
     	if(Pagesource.contains("email")) 
		{
			System.out.println("element present at pagesource");
			
			//findelement throw Nosuchelement exception incase element not presented at pagesource
			WebElement Email=driver.findElement(By.xpath("//input[@id='email']"));
			Email.clear();
			Email.sendKeys("darshan");
		}
		else 
		{
			System.out.println("element not presented at pagesource");
		}
		
		
		//we can also use try ,catch block as alternative method
		
		try 
		{
			//findelement throw Nosuchelement exception incase element not presented at pagesource
	         WebElement password=driver.findElement(By.id("pass"));
	         password.clear();
	        password.sendKeys("hello");
		}catch(Exception e) 
		{
			System.out.println("element not found at source");
		}

	}

}

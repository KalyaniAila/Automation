package ui_page_verification_commands;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Verify_PageUrl 
{

	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://selenium.dev");
		driver.manage().window().maximize();
		
		//get currnet page url
		String Runtime_url=driver.getCurrentUrl();
		System.out.println("current page url---->"+Runtime_url);
		
		String Exp_url="https://www.selenium.dev/";
		
		//verify url presented at page source
		if(Exp_url.contains(Exp_url)) 
		{
			System.out.println("url verified for homepage");
		}
		
		if(Exp_url.equals(Runtime_url)) 
		{
			System.out.println("expected url match with runtime url");
		}


	}

}

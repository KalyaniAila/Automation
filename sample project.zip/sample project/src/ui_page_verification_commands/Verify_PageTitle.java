package ui_page_verification_commands;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Verify_PageTitle 
{

	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://selenium.dev/");
		driver.manage().window().maximize();
		
		//get current page title
		String Runtime_title=driver.getTitle();
		System.out.println("current page title is--->"+Runtime_title);
		
		String Exp_title="SeleniumHQ Browser Automation";
		 
		//conditional statement to verify expected title presented at webpage
		if(Runtime_title.equals(Exp_title)) 
		{    
			System.out.println("selenium homepage title verified");
		}

	}

}
  
package wait_commands;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;

public class Explicitwait_syntax 
{
	WebDriver driver;
	String Driver_path="Drivers\\";
	String url="https://www.selenium.dev";
	
  @Test
  public void testcase() 
  {
	  //Enable Explicit wait on automation browser
	  WebDriverWait wait=new WebDriverWait(driver, 50);
	  
	  //manage timegap until expected title load
	  String Exp_title="SeleniumHQ Browser Automation";
	  wait.until(ExpectedConditions.titleIs(Exp_title));
	  System.out.println("expected title presented");
	  
	  String title="Selenium";
	  wait.until(ExpectedConditions.titleContains(title));
	  System.out.println("expected title present");
	  
  }
  
  @BeforeClass
  public void beforeClass() 
  {
	  System.setProperty("webdriver.chrome.driver", Driver_path+"chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	  driver.get(url);
	  driver.manage().window().maximize();
  }

  @AfterClass
  public void afterClass() 
  {
	  driver.close();
  }

}

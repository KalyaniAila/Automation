package wait_commands;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;

public class Explicitwait_AlertPresented
{
	WebDriver driver;
	String Driver_path="Drivers\\";
	String url="http://demo.automationtesting.in/Alerts.html";
	
  @Test
  public void testcase() throws Exception 
  {
	  //Enable explicit wait on automation browser
	   WebDriverWait wait=new WebDriverWait(driver, 50);
	   Thread.sleep(3000);
	   
	   WebElement alert_with_OK_link=driver.findElement(By.xpath("(//a[@class='analystic'])[1]"));
	   alert_with_OK_link.click();
	   Thread.sleep(4000);
	   
	   WebElement alert_prompt_link=driver.findElement(By.xpath("//button[@onclick='alertbox()']"));
	   alert_prompt_link.click();  //this prompt alert at webpage
	   Thread.sleep(4000);
	   
	   //wait until alert presented at webpage
	   wait.until(ExpectedConditions.alertIsPresent()).accept();
	   System.out.println("alert presented at webpage");
  }
  
  @BeforeClass
  public void beforeClass() 
  {
	  System.setProperty("webdriver.chrome.driver", Driver_path+"chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.get(url);
	  driver.manage().window().maximize();
  }

  @AfterClass
  public void afterClass() throws Exception 
  {
	  Thread.sleep(4000);
	  driver.close();
  }

}

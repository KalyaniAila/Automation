package wait_commands;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class Implicitwaits 
{
	WebDriver driver;
	String Driver_path="Drivers\\";
	String url="https://www.google.com/";
	
  @Test
  public void testcase() 
  {
	  long Start_time=System.currentTimeMillis();
	  long End_time;
	  try
	  {
		  driver.findElement(By.id("email"));
		  End_time=System.currentTimeMillis();
		  System.out.println("object verified at facebook");
		  
		  driver.findElement(By.id("FromTag"));
		 // long End_time=System.currentTimeMillis();
		  System.out.println("object verified at cleartrip");
		  
		  
	   } catch (NoSuchElementException e)
	   {
		    End_time=System.currentTimeMillis();
	   }
	  System.out.println(End_time-Start_time);
	  
  }
  
  @BeforeClass
  public void beforeClass() 
  {
	  System.setProperty("webdriver.chrome.driver",Driver_path+"chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS)
	  .pageLoadTimeout(50,TimeUnit.SECONDS)
	  .setScriptTimeout(50,TimeUnit.SECONDS);
	  driver.get(url);
	  driver.manage().window().maximize();
  }

  @AfterClass
  public void afterClass() 
  {
	  driver.close();
  }

}

package wait_commands;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;

public class Explicit_wait_for_url
{
	WebDriver driver;
	String Driver_path="Drivers\\";
	String url="https://www.selenium.dev/";
	
  @Test
  public void testcase() 
  {
	  //enable explicit wait on automation browser
	  WebDriverWait wait=new WebDriverWait(driver, 50);
	  
	  String exp_url="https://www.selenium.dev/";
	  wait.until(ExpectedConditions.urlToBe(exp_url));
	  System.out.println("expected url presented at browser window");
	  
	 // wait.until(ExpectedConditions.urlContains("dev"));
	 // System.out.println("partial url pesented at browser window");
	  
	  //manage explicit wait intil expected url present
	  WebElement download_btn=driver.findElement(By.xpath("(//div[contains(.,'DOWNLOAD')])[4]"));
	  download_btn.click();
	  
	  //manage explicit wait until partial url present
	  wait.until(ExpectedConditions.urlContains("/downloads/"));
	  System.out.println("download page url presented at browser window");
	  
  }
  
  @BeforeClass
  public void beforeClass() 
  {
	  System.setProperty("webdriver.chrome.driver", Driver_path+"chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.get(url);
	  driver.manage().window().maximize();
	  
  }

  @AfterClass
  public void afterClass() throws Exception 
  {
	  Thread.sleep(4000);
	  driver.close();
  }

}

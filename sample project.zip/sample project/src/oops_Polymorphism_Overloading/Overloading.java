package oops_Polymorphism_Overloading;

public class Overloading 
{
	
	//same method with different parameters
	void product(int ID) 
	{
		System.out.println(ID);
	}
	void product(String name) 
	{
		System.out.println(name);
	}
	void product(int ID ,String name) 
	{
		System.out.println(ID+" "+name);
	}
	void product(String name,int ID) 
	{
		System.out.println(name+" "+ID);
	}

	public static void main(String args[]) 
	{
		//create object for overloading object
		Overloading obj=new Overloading();
		obj.product(100);
		obj.product("Iphone");
		obj.product(102, "phone");
		obj.product("Vivo", 108);
	}
}

package ui_element_verificationcommands_getattribute;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Get_Runtime_Attribute 
{

	public static void main(String[] args) 
	{
		      
		/*  Scenario:-->  Verify Roundtrip Selection State 
		 * 
		 *                         Given site url is "http://makemytrip.com"
		 *                         And verify default selection for oneway
		 *	                       When user click on Return date\
		 *		                  Then selection changes to Roundtrip radio button   
		 */
		
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.makemytrip.com/");
		driver.manage().window().maximize();
		   
		WebElement Oneway_Sbtn=driver.findElement(By.xpath("//li[@data-cy='oneWayTrip']"));
		String oneway_Runtime_class=Oneway_Sbtn.getAttribute("class");	
		System.out.println("class property available at runtime----->"+oneway_Runtime_class);
		
		if(oneway_Runtime_class.equals("selected")) 
		{
			System.out.println("oneway selected as default");
			
			WebElement Return_date=driver.findElement(By.xpath("(//span[@class='lbl_input latoBold appendBottom10'])[2]"));
			Return_date.click();
			
			WebElement Roundtrip_sbtn=driver.findElement(By.xpath("//li[@data-cy='roundTrip']"));
			String Roundtrip_Runtime_class=Roundtrip_sbtn.getAttribute("class");
			System.out.println("class property available at runtime--->"+Roundtrip_Runtime_class);
			
			if(Roundtrip_Runtime_class.equals("selected")) 
			{
				System.out.println("testpass,Roundtrip selected when click on Return date ");
			}
	  		else 
			{
				System.out.println("testfail,Rountrip is not selected when click on Return date");
			}
			
			{
				System.out.println("precondition failed,oneway is not selected on browser launched");
			}
						
			
		}
				 
		 

	}

}

package ui_element_verificationcommands_getattribute;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Validate_Currentsystem_Date
{

	public static void main(String[] args)
	{
	 /*
	  * scenario:-Verify depature date matching with current system date.
	  */

		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.spicejet.com/");
		driver.manage().window().maximize();
		
		WebElement departue_date = driver.findElement(By.xpath("//input[@id='ctl00_mainContent_view_date1']"));
		
		//get input value from textbox
		String departue_date1=departue_date.getAttribute("value");
		System.out.println("default departue date format---->"+departue_date1);
		
		//get current system date
		Date d=new Date();
		     // d.getDate("")
		
		//create simple date format
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM");
		//convert system date using simple date formatter
		String sdate=sdf.format(d);
		System.out.println("system date in departue date format--->"+sdate);
		
		//verify system date equals to departue date                                                 
		if(sdate.equals("departue_date")) 
		{
			System.out.println("Testpass,departue date match with system date");
		}
		else 
		{
			System.out.println("testfail,departue date mismatch with system date");
		}
		
	}
	
}

             /* Date formatters:-->
		 * 
		 * 		yyyy =>    year   [2019]
		 * 		  yy =>    year   [19]
		 * 		  MM =>    Month  [01-12]
		 * 		MMM  =>    Month  [Jan -Dec]
		 * 		EEE  =>    week   [sun -sat]
		 * 		  dd =>    date   [01-31]
		 * 		  hh =>    hour   [01-24]
		 * 		  mm =>    minute [01-60]
		 * 		  ss =>    Seconds[01-60]
		 * 		
		 */
            




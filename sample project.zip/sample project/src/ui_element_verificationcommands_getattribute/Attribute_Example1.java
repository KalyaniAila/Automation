package ui_element_verificationcommands_getattribute;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Attribute_Example1
{

	public static void main(String[] args) throws Exception 
	{
		/* scenario:- Verify roundtrip selection state:-
		 * 
		 *                   Given site url is"http://spicejet.com"
		 *                  and verify default  selection for oneway
		 *                  When user click return date/
		 *                 The Selection chnages to roundtrip radio button.
		 */
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://spicejet.com");
		driver.manage().window().maximize();
	   
		WebElement oneway_label=driver.findElement(By.xpath("//input[@id='ctl00_mainContent_rbtnl_Trip_0']"));
		String Runtime_oneway_class=oneway_label.getAttribute("class");   //Here class is 'attribute name' ,it return 'attribute value'
		System.out.println("class property available at rntime---->"+Runtime_oneway_class);
		
		//if(Runtime_oneway_class.equals("select_label")) 
		//{
		//	System.out.println("oneway selected as default options");
			
		//	WebElement Return_date=driver.findElement(By.xpath("//input[@id='date2']"));
		//	Return_date.click();
			//Thread.sleep(2000);
		//}
		
		

	}

}

package ui_element_verification_commands_getText;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Verify_ElementText 
{

	public static void main(String[] args) throws Exception 
	{
		/*   
		 * scenario:-   verify login with invalid email:-
		 *      Given site url "http://outlook.com"
		 *      and click signin button
		 *      when user enter invalid email "info@gmail.com"
		 *      and Next button
	     *       Then verify error msg displayed at webpage   
		 */
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://outlook.com");
        driver.manage().window().maximize();
        
        WebElement element=driver.findElement(By.xpath("(//a[@data-task='signin'])[1]"));
        element.click();
        WebElement email=driver.findElement(By.xpath("//input[@id='i0116']"));
        email.clear();
        email.sendKeys("kalyaniaila1998@gmail.com"+Keys.ENTER);
        Thread.sleep(5000);
       
        WebElement Error_location=driver.findElement(By.xpath("//div[@id='usernameError']"));
		String Error_text=Error_location.getText();
		System.out.println(Error_text);
		
		
		if(!Error_text.isEmpty()) 
		{
			String Exp_errmsg="You can't sign in here with a personal account. Use your work or school account instead.";
		
			if(Error_text.equals(Exp_errmsg))
				System.out.println("Testpass, Expected error msg displayed");
			else
				System.out.println("Testfail, Wrong error message displayed");
		}
		else
			System.out.println("OBject may not visble or not contains text");
		

	
	}

}

package ui_element_verification_commands_getText;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Verify_Expected_Records_Availableat_Table 
{

	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();                 //launch browser
		driver.get("https://www.icicidirect.com/equity");     //
		driver.manage().window().maximize();  
		  
	  

	}

}
      
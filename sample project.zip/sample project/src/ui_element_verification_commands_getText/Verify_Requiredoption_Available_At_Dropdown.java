package ui_element_verification_commands_getText;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Verify_Requiredoption_Available_At_Dropdown 
{

	public static void main(String[] args) throws Exception 
	{
		/*
		 * scenario:-Verify citydropdown displayed citynames acoording to state selection
		 * 
		 *                Given site url "https://v1.hdfcbank.com/branch-atm-locator"
		 *                When user select any state
		 *                Then verify expected cities listout at city dropdown
		 */
		System.setProperty("webdriver.chrome.driver","Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://v1.hdfcbank.com/branch-atm-locator");
		driver.manage().window().maximize();
		
		//Select state dropdown
	   Select state_dropdown=new Select(driver.findElement(By.xpath("//select[@id='customState']")));
	   state_dropdown.selectByVisibleText("Bihar");
	   Thread.sleep(5000);
	   
	   //read all city dropdown options
	   WebElement city_dropdown=driver.findElement(By.xpath("//select[@id='customCity']"));
	   String All_Cities =city_dropdown.getText();
	   //System.out.println(All_Cities);
	   
	   if(All_Cities.contains("Haryana")) 
	   {
		   System.out.println("testpass,expected city availabe at dropdown");
	   }
	   else 
	   {
		   System.out.println("testfail,expected city not avilable at dropdown");
	   }

	}

}

package cls;

import java.util.TreeSet;

public class TreesetTest {

	public static void main(String[] args) {
		
		
		TreeSet<String> treeSet = new TreeSet<>();
		treeSet.add("George");
		treeSet.add("Fills");
		treeSet.add("George");
		for (String str :treeSet)
			System.out.println(str +" ");
			
		}

	}



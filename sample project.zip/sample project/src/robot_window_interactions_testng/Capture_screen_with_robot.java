package robot_window_interactions_testng;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;

public class Capture_screen_with_robot 
{
	WebDriver driver;
	String Driver_path="Drivers\\";
	String url="https://swisnl.github.io/jQuery-contextMenu/demo.html";
	
	
  @Test
  public void f() throws Exception 
  {
	  WebElement element=driver.findElement(By.xpath("//span[.='right click me']"));
	   
	   //create object for action class
	   Actions actions=new Actions(driver);
	   actions.contextClick(element).perform();
	   
	   WebElement delete_btn=driver.findElement(By.xpath("//span[.='Delete']"));
	   //this action prompt alert 
	   delete_btn.click();
	   Thread.sleep(4000);
	   
	   //get system dimension
	   //Dimension screensize=Toolkit.getDefaultToolkit().getScreenSize();
	   Dimension Screensize=Toolkit.getDefaultToolkit().getScreenSize();
	   //create rectangle screen using dimension
	   Robot robot=new Robot();
	   BufferedImage screenimg=robot.createScreenCapture(new Rectangle(Screensize));
	   
	   //get default system time
	    Date d=new Date();
	 	//Crate simple date format
	 	DateFormat df=new SimpleDateFormat("yyyy-MMM-dd hh-mm-ss");
	 	//Convert Default date using dateformatter
	 	String time=df.format(d);
	 			
	 	
	   
	   //write image into local files
	   File path= new File("C:\\Users\\Pandu\\Desktop\\Screenshot\\"+time+"image.png");
	   
	   //ImageIO.write(Bufferedimage,"Imageextension",path of file)
	   ImageIO.write(screenimg,"PNG",path);
	   
	   
  }
  
  
  @BeforeClass
  public void beforeClass() 
  {
	  System.setProperty("webdriver.chrome.driver", Driver_path+"chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.get(url);
	  driver.manage().window().maximize();
  }
  
  

  @AfterClass
  public void afterClass() throws Exception 
  {
	  Thread.sleep(3000);
	  driver.close();
  }

}

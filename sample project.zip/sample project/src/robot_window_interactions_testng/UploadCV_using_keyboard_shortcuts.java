package robot_window_interactions_testng;

import org.testng.annotations.Test;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class UploadCV_using_keyboard_shortcuts
{
	WebDriver driver;
	String Driver_path="Drivers\\";
	String url="https://naukri.com";
	
	
  @Test
  public void testcase() throws Exception 
  {
	  WebElement upload_cv=driver.findElement(By.xpath("//label[@id='wdgt-file-upload']"));
	  upload_cv.click();
	  
	  String path="C:\\Users\\Pandu\\downloads\\Testng\\Test_priority";
	  
	  //before copy to clipboard select a string
	  StringSelection spath=new StringSelection(path);
	  
	  //get system default clipboard
	  Clipboard clipboard=Toolkit.getDefaultToolkit().getSystemClipboard();
	  //set copied string contents to clipboard
	  clipboard.setContents(spath, spath);
	  
	  //create object for robot
	  Robot robot=new Robot();
	  robot.setAutoDelay(500);
	  
	  //use keyboard action ctrl+v
	  robot.keyPress(KeyEvent.VK_CONTROL);
	  robot.keyPress(KeyEvent.VK_V);
	  
	  //press enter key
	  robot.keyPress(KeyEvent.VK_ENTER);
	  
	  
  }
  
  
 @BeforeClass
  public void beforeClass()
  {
	  System.setProperty("webdriver.chrome.driver", Driver_path+"chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.get(url);
	  driver.manage().window().maximize();
  }
  
  

  @AfterClass
  public void afterClass() throws Exception 
  {
	  Thread.sleep(3000);
	  driver.close();
  }

}

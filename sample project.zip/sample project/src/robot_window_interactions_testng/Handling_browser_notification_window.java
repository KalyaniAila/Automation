package robot_window_interactions_testng;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import java.awt.Robot;
import java.awt.event.InputEvent;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class Handling_browser_notification_window 
{
	WebDriver driver;
	String Driver_path="Drivers\\";
	String url="https://www.cleartrip.com";
	
	
  @Test
  public void testcase() throws Exception 
  {
	  //create object for robot
	  Robot robot=new Robot();
	  robot.setAutoDelay(500);
	  
	  //mouse move cursor to location
	  //robot.mouseMove(, );
	  
	  //left click using mouse
	  robot.mousePress(InputEvent.BUTTON1_MASK);
	  robot.mousePress(InputEvent.BUTTON1_MASK);
	  
	  //scroll
	  robot.mouseWheel(100);
  }
  
  
  @BeforeClass
  public void beforeClass() 
  {
	  System.setProperty("webdrivr.chrome.driver", Driver_path+"chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.get(url);
	  driver.manage().window().maximize();
  }
  

  @AfterClass
  public void afterClass() throws Exception 
  {
	  Thread.sleep(4000);
	  driver.close();;
  }

}

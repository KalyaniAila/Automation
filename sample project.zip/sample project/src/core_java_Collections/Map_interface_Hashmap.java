package core_java_Collections;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Map_interface_Hashmap 
{


	public static void main(String[] args)
	{
		/*   =>map store pair of objects only with key and value format
		 *   =>map is sorted list of set it doesn't accept duplicate  end
		 *   =>unorder collection
		 *   =>Hash map accept one null value 
		 * 
		 */
		Map<Integer, String> map=new HashMap<Integer,String>();
		map.put(103, "Samsung");
		map.put(104, "Vivo");
		map.put(105, "Oppo");
		map.put(106, "Iphone");
		
		//retrieve data from collection
		String value =map.get(106);
		System.out.println(value);
		
		//read all hashmap values using foreach loop
		Set<Integer> keys=map.keySet();
		for (Integer keyname : keys) 
		{
			System.out.println(keyname);
		}
		
		for (int i = 0; i < map.size(); i++) 
		{
			String obj=map.get(i);
			System.out.println(obj);
		}

	}

}

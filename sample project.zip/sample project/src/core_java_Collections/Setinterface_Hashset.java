package core_java_Collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Setinterface_Hashset 
{

	public static void main(String[] args) 
	{
		//store objects in Random order  
		Set<String> Set=new HashSet<String>();
		Set.add("one");
		Set.add("two");
		Set.add("three");
		Set.add("four");
		Set.add("five");
		Set.add("two");
		System.out.println("object count--->"+Set);
		
		//Remove objects from collection
		Set.remove("two");
		
		//get object count
		int count=Set.size();
		System.out.println("object count---->"+count);
		
		//verify object contains at collection 
		boolean flag=Set.contains("two");
		System.out.println("object available status is----->"+flag);
		
		//read frst iterator value
		String itr=Set.iterator().next();
		System.out.println("next iterator value at collection--->"+itr);
		
		//verify collection empty status
		boolean flag1=Set.isEmpty();
		System.out.println("is collection is empty?--->"+flag1);
		
		//clear all objects at collection
		//Set.clear();
		
		//read all collection objects using foreach loop
		for (String eachobj : Set) 
		{
			System.out.println("#--->"+eachobj);
		}
		
		//read all objects using iterator class
		Iterator<String> tokens=Set.iterator();
		
		System.out.println("\n");
		
		//use while loop to iterate until it has last iteration
		while(tokens.hasNext()) 
		{
			String value=tokens.next();
			System.out.println("=>---->"+value);
		}


	}

}

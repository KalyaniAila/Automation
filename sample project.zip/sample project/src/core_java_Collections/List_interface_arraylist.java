package core_java_Collections;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class List_interface_arraylist
{

	public static void main(String[] args) 
	{
		  		
		//store objects in alphatical order
		List<String>list=new ArrayList<String>();
		list.add("one");
		//System.out.println(order);
		list.add("two");
		list.add("three");
		
		list.add("four");
		list.add("five");
		list.add("two");
		System.out.println("object order--->"+list);
		
		/*  because list accept collection of object inorder list ,allow any single object to return 
		  *   using its inorder number
		 *     
		  *    Note:-get(index num)  
		  */  
		
		String obj=list.get(3);
		System.out.println(obj);
				
		//remove object from collection
		boolean obj1=list.remove("two");
		System.out.println(obj1);
				
		//verify object contains at collection
		boolean flag= list.contains("three");
		System.out.println("object avilable status--->"+flag);
				
		//get size(count) of iterator
		int count=list.size();
		System.out.println("object count is--->"+count);
				
		//read iterator frst value
		String itr=list.iterator().next();
		System.out.println("object frst iterator value---->"+itr);
				
		//verify object empty status
		boolean flag1=list.isEmpty();
	    System.out.println("is the collection is empty?--->"+flag1);
				
		//clear collection
		//list.clear();
	    
	    //read colection interface using for loop
	    for (int i = 0; i < list.size(); i++) 
	    {
			String Eachobj=list.get(i);
			System.out.println(Eachobj);
		}
	    
	    System.out.println("\n");
				
		//read collection objects using for each loop
		for (String eachobj : list) 
		{
			System.out.println("#"+eachobj);
		}
				
				
		System.out.println("\n");
				
		//read all objects using iterator class
		Iterator<String> tokens=list.iterator();
				
		//using while loop ,iterate until last iteration
		while (tokens.hasNext()) 
		{
			String value =  tokens.next();
			System.out.println("=>"+value);
					
		}

	}

		


	}



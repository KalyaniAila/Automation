package core_java_Collections;

import java.util.HashSet;
import java.util.Set;

import org.testng.annotations.Test;

public class Set_interface_Hashset 
{
	
  @Test
  public void test1() 
  {
	//store objects in Random order  
	Set<String> Set=new HashSet<String>();
	Set.add("one");
	Set.add("two");
	Set.add("three");
	Set.add("four");
	Set.add("five");
	Set.add("two");
	//System.out.println("object count--->"+true);
	
	//Remove objects from collection
	Set.remove("two");
	
	//get object count
	int count=Set.size();
	System.out.println("object count---->"+count);
  }
}

package core_java_Collections;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class Set_Interface_Treeset 
{

	public static void main(String[] args) 
	{
		//store objects in alphatical order
		Set<String> set=new TreeSet<String>();
		set.add("one");
		//System.out.println(order);
		set.add("two");
		set.add("three");
		set.add("four");
		set.add("five");
		set.add("two");
		System.out.println("object order--->"+set);
		
		//remove object from collection
		boolean obj1=set.remove("two");
		System.out.println(obj1);
		
		//verify object contains at collection
		boolean flag= set.contains("three");
		System.out.println("object avilable status--->"+flag);
		
		//get size(count) of iterator
		int count=set.size();
		System.out.println("object count is--->"+count);
		
		//read iterator frst value
		String itr=set.iterator().next();
		System.out.println("object frst iterator value---->"+itr);
		
		//verify object empty status
		boolean flag1=set.isEmpty();
		System.out.println("is the collection is empty?--->"+flag1);
		
		//clear collection
		//set.clear();
		
		//read collection objects using for each loop
		for (String eachobj : set) 
		{
			System.out.println("#"+eachobj);
		}
		
		
		System.out.println("\n");
		
		//read all objects using iterator class
		Iterator<String> tokens=set.iterator();
		
		//using while loop ,iterate until last iteration
		while (tokens.hasNext()) 
		{
			String value =  tokens.next();
			System.out.println("=>"+value);
			
		}

	}

}

package webdriver2;

public class Chrome
{
    void chromebrowser() 
	{
		System.out.println("browserlaunch");
	}
	static void opensite()
	{
		System.out.println("open");
	}
	static void closesite() 
	{
		System.out.println("close");
	}
	public static void main(String args[]) 
	{
		//calling static method
		opensite();   //methodname();
		closesite();
		
		//calling instant method
		new Chrome().chromebrowser();    //new classname.methodname();   
	}
	

}

package webdriver2.parameters;

public class  Browsers
{
	//method without parameters
	void chromebrowser()
	{
		System.out.println("chrome browser launched");
	}
	
	//method with parameters
	void openbrowser(String Browsername)
	{
		
		System.out.println(Browsername+"--->Browser launched");   //
	}
	
	public static void main(String args[])
	{
		
		//we can't call instant method to static method ,calling should be through object creation
		
		Browsers obj=new Browsers();       //classname obj=new classname();
		obj.chromebrowser();              //obj(ref):here obj store the browsers value ,
		obj.openbrowser("chrome");
		obj.openbrowser("safari");
	}
		

}

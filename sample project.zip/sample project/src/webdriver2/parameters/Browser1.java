package webdriver2.parameters;

public class Browser1
{
	//Method with multiple parameters
	void printtool(String toolname ,Double toolprice) 
	{
	  System.out.println(toolname);
	  System.out.println(toolprice);
	}
	
	
	public static void main(String[] args)
	{
		//we can't call instant method to static method,calling sholud be through object creation 
		
	 
		Browser1 obj=new Browser1();              //classname obj=new classname();
	   
		obj.printtool("webdriver", 100.00);
	    obj.printtool("QTP", 12000.02);
		

	}

}


   
    	
    


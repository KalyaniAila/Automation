package webdriver2.parameters.returntypes;

public class product 
{
	//Voiid method doesnot return any value
	void infoproduct()
	{
		System.out.println("Apple12,6GB RAM,128GB ROM");
		
	}
	String getproductprice()
	{
		return "50000.00";
	}
	int Quality() 
	{
		int a=10;
	    return a;
	}
	

	public static void main(String[] args) 
	{
	product obj=new product();            //cassname obj=new classname
	obj.infoproduct();                   //obj.methodname();
	//calling string return method
	String name=obj. getproductprice();
	System.out.println(name);
	
	//calling integer return method
	int num=obj.Quality();
    System.out.println(num);
     
    }

}

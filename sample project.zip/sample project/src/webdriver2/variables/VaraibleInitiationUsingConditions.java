package webdriver2.variables;

public class VaraibleInitiationUsingConditions
{

	public static void main(String[] args)
	{
	   
		if(true) 
		{
			String name="webdriver";
		}
		//System.out.println(name);          //this syntax shows runtime error ask to create local variable 
		
		//Global initiation
		String toolname;                   //String toolname="WD"
		if(true) 
		{
			toolname="Appium";
		}
		System.out.println(toolname);
		
		
		//global initilazation
		
		String browsername;
		if(true) 
		{
			browsername="chrome";
		}
		System.out.println(browsername);
		
	//	void mobile() 
		{
			int price=100;
			System.out.println(price);
			
		}

	}

}

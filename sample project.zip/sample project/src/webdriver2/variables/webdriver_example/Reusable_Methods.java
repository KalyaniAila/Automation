package webdriver2.variables.webdriver_example;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Reusable_Methods 
{
	String Driver_path;
	WebDriver driver;
	String url;
	String username;
	String password;
	
	public void Launchbrowser()
	{
		public static void main(String args[]) 
		{
		
			if(browser_name.equals("chrome")) 
			   {
				 System.setProperty("webdriver.chrome.driver",Driver_path+"chromedriver.exe");
				 driver=new ChromeDriver();
			    }
			    else if(browser_name.equals("firefox"))
			   {
				 System.setProperty("webdriver.gecko.driver",Driver_path+"geckodriver.exe");
				 driver=new FirefoxDriver();
			   }
			  else 
			  {
				System.out.println("browser name mismatch failed to initiate browsername");
			  }
			
			  public void Get_App() 
			  {
				driver.get(url);
				driver.manage().window().maximize();
			  }
			
			  public void User_login() 
			 {
				driver 
			 }
			  
		
		}
		
	
	}
			
		
		  
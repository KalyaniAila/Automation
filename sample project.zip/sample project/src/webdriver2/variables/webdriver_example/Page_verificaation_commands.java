package webdriver2.variables.webdriver_example;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Page_verificaation_commands
{

	public static void main(String[] args) 
	{ 
	 System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
	 WebDriver driver=new ChromeDriver();
	 driver.get("http://selenium.dev");
	 driver.manage().window().maximize();
	 
	 String Runtime_title=driver.getTitle();
	 System.out.println("current window title is--->"+Runtime_title);
	 
	 String Runtime_Url=driver.getCurrentUrl();
	 System.out.println("current window url--->"+Runtime_Url);
	 
	 String Pagesource=driver.getPageSource();
	 System.out.println(Pagesource);
	 
	 String windowID=driver.getWindowHandle();
	 System.out.println("Runtime window ID available---->"+windowID);

	}             

}

package webdriver2.variables.webdriver_example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Reusable_Objects_pageobjectmodel 
{
	//POM--->Page Object Model                                                 
	  public static By Login_Email=By.xpath("//input[contains(@id='email')]");                 
	  public static By Login_Password=By.xpath("//input[contains(@data_testid,'royal_pass')]");
	  public static By Login_Submitt_btn=By.xpath("//button[contains(@data_testid,'button')]");
	  
	  public static void main(String[] args) throws Exception 
	{
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://facebook.com");
		driver.manage().window().maximize();
		
		Thread.sleep(2000);
		
        driver.findElement(Login_Email).sendKeys("kalyani");
		Thread.sleep(2000);
		driver.findElement(Login_Password).sendKeys("Helloo");
		driver.findElement(Login_Submitt_btn).click();        
		
		  
	}           

}   
                                                                                                              
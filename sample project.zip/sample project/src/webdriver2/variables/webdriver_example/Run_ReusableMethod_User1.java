package webdriver2.variables.webdriver_example;

import org.openqa.selenium.WebDriver;


public class Run_ReusableMethod_User1 
{
	static WebDriver driver;

	public static void main(String[] args)
	{
		//Create object for reusable methods
		Reusable_Methods obj=new Reusable_Methods();
		obj.Browser_name="chrome";
		obj.driver_path="Drivers\\";
		Obj.lauch_bowser();
		
		
		
		
		
		
		
		

	}

	
		
	

}

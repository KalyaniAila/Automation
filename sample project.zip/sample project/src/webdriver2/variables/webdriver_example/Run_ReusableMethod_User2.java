package webdriver2.variables.webdriver_example;

public class Run_ReusableMethod_User2 
{

	public static void main(String[] args) 
	{
		

	}

}

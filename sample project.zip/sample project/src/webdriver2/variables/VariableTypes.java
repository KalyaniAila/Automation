package webdriver2.variables;

public class VariableTypes 
{
	
 public static void main(String args[]) 
 {
	String toolname="WD";

	//static int a=10;	
	
//	public void method1() ;
	{
		String name="MQ";
	
	}
	//public void  method2()
	{
		System.out.println(toolname);
	}

  

	
  }
 
}
  

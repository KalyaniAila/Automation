package webdriver2.variables;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Global_InitiationWith_WebdriverExample 
{

	public static void main(String[] args) 
	{
	 String browser="chrome";
	 WebDriver driver = null;
	 if(browser.equals("chrome")) 
	 { 
		 System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		 driver=new ChromeDriver();
	 }
	 else if(browser.equals("firefox")) 
	 {
		 System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		 driver=new FirefoxDriver();
	 }
	 driver.get("http://facebook.com");
	 System.out.println(driver.getTitle());
	 driver.close();             

	}

}

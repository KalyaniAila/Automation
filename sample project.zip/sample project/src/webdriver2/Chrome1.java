package webdriver2;

public class Chrome1
{
	public static void main(String args[])
	{
		//calling static to static method,to anthoer class
		Chrome.opensite();     //classname.methodname();
		Chrome.closesite();
		
		//calling instant to static method from another class
		new Chrome().chromebrowser();   //new classname.methodname();
	}
	
	

}

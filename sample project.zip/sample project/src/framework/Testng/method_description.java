package framework.Testng;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class method_description 
{
	
	
  @Test(priority=0, description="")
  public void t1() 
  {
	  Reporter.log("t1 executed");
  }
  
  @Test()
  public void t2() 
  {
  }

  
  @Test()
  public void t3()
  {
  }

}

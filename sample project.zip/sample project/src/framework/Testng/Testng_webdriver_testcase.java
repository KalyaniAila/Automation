package framework.Testng;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;

public class Testng_webdriver_testcase
{
	
    WebDriver driver;
	String Driver_path="Drivers\\";
	String url="http://facebook.com";
	String screen_path="C:\\selenium java\\sample project\\Screens";
	
	
  @Test
  public void Tc001_verify_signup_link() 
  {
	  driver.findElement(By.xpath("//a[contains(@title,'Sign up for Facebook')]")).click();
	  String exp_title="Facebook- login or sign up";
	  Assert.assertEquals(exp_title, driver.getTitle());
	  Reporter.log("sign up page verified");
  }
  
  @Test
  public void Tc002_verify_login_link() 
  {
	  driver.findElement(By.xpath("//a[@title='Log in to Facebook']")).click();
	  String exp_title="Log in to Facebook";
	  Assert.assertEquals(exp_title, driver.getTitle());
	  Reporter.log("login page verified");
  }
  
  @Test
  public void Tc003_verify_messenger_link() 
  {
	  driver.findElement(By.xpath("//a[@title='Take a look at Messenger.']")).click();
	  String exp_title="Messenger";
	  Assert.assertEquals(exp_title, driver.getTitle());
	  Reporter.log("messenger page verified");
  }
  
  @Test
  public void Tc004_verify_facebook_lite_link() 
  {
	  driver.findElement(By.xpath("//a[@title='Facebook Lite for Android.']")).click();
	  String exp_title="Facebook Lite for Android";
	  Assert.assertEquals(exp_title, driver.getTitle());
	  Reporter.log("Facebook lite page verified");
  }


  @BeforeMethod
  public void beforeMethod()
  {
	 driver.get(url);
  }
  
  
  //Method Parameter allow to access current constructed @Test method name

  @AfterMethod
  public void afterMethod() throws Exception
  {
	  //capture screen at automation browser and convert it into file format
	  File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	  //copy file folder
	  FileHandler.copy(src, new File(screen_path));
  }
  

  @BeforeClass
  public void beforeClass() 
  {
	  System.setProperty("webdriver.chrome.driver", Driver_path+"chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.get(url);
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
  }
  

  @AfterClass
  public void afterClass() throws Exception 
  {
	  Thread.sleep(3000);
	  driver.close();
  }

}

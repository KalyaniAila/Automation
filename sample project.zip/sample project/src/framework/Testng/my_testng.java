package framework.Testng;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class my_testng 
{
	
  @Test
  public void f()
  {
	  Reporter.log("f executed");
  }
}

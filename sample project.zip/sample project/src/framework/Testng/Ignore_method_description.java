package framework.Testng;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class Ignore_method_description
{
	
  @Test
  public void tc001()
  {
	  Reporter.log("tc001 executed");
  }
  
  
  //this property ignore method exection
  @Test(enabled=false)
  public void tc002() 
  {
	  Reporter.log("tc002 exected");
  }
  
  @Test
  public void tc003() 
  {
	  Reporter.log("tc003 excuted");
  }
}

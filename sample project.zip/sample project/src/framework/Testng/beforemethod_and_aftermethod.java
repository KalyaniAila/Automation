package framework.Testng;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;

public class beforemethod_and_aftermethod 
{
	
  @Test
  public void test() 
  {
	  Reporter.log("test run executed,true");
  }
  
  @Test
  public void test1() 
  {
	  Reporter.log("test1 run executed,true");
  }

  //The annotated method will be run before each test method
  @BeforeMethod
  public void beforeMethod()
  {
	  System.out.println("pre condition for method");
  }
  
  //the annotated method will be run after each test method
  @AfterMethod
  public void afterMethod() 
  {
	  System.out.println("post condition for method");
  }

}

package framework.Testng;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;

public class beforeclass_and_afterclass 
{
	
  @Test
  public void test1() 
  {
	  Reporter.log("test1 run wxecuted,true");
  }
  
  @Test
  public void test2() 
  {
	  Reporter.log("test2 run executed,true");
  }

  
  //the annotated method will be run before the  first test method in the current class is invoked
  @BeforeClass
  public void beforeClass() 
  {
	  System.out.println("pre condition for class");
  }
  
  
   //the annotated method will be run after all the  test methods in the current class is run
  @AfterClass
  public void afterClass()
  {
	  System.out.println("post condition for class");
  }

}

package oops_Polymorphism_Overriding;

public class ChildA extends Parent
{
	void run(int km) 
	{
		System.out.println(km);
	}
	
	public static void main(String args[]) 
	{
		Parent obj=new ChildA();
		obj.run(10);
	}

}

package oops_Polymorphism_Overriding;

public class  Parent 
{
	void run(int km) 
	{
		System.out.println("parent run method--->"+km);
	}


	public static void main(String args[]) 
	{
		//new ChildA();
		
	}

}

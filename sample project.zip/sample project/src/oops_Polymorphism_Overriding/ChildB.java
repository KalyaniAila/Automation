package oops_Polymorphism_Overriding;

public class ChildB extends Parent 
{
	@Override
	void run(int km) 
	{
		System.out.println("childB run method--->"+km);
	}

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Parent obj=new ChildB();
		obj.run(23);
		

	}

}

package oops_Polymorphism_Overriding;

public class ChildC extends Parent 
{
	void run(int km) 
	{
		//it run parent run method
		super.run(20);                                    // o/p:-parent run method -->20
		System.out.println("childc run method--->"+km);  //o/p:-45
	}

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Parent obj=new ChildC();
		obj.run(45);

	}

}

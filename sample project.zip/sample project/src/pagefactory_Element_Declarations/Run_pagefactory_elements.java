package pagefactory_Element_Declarations;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

public class Run_pagefactory_elements 
{

	public static void main(String[] args) throws Exception 
	{
		System.setProperty("webdriver.chrome.driver","Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://www.facebook.com/r.php");
		
		/*   In order to get acess to @findby method we should
		 *        take help of pagefactory class 
		 */
		Element_Declations ED=PageFactory.initElements(driver,Element_Declations.class);
		ED.firstname_FB.sendKeys("Newuser");
		Thread.sleep(2000);
		
		
		//print all page links count
		//ED.page_links.size();
		System.out.println("link count at webpage---->"+ED.page_links.size());
		Thread.sleep(2000);
		
		//Get dropdown count at webpage
		System.out.println("dropdown count is--->"+ED.Dropdown.size());
		
		//select fifth option under dropdown
		boolean flag=ED.Dropdown.get(0).getText().contains("31");
		System.out.println(flag);
		Thread.sleep(2000);
		
		//select dec month
		ED.Month_Options.get(10).click();
		Thread.sleep(3000);
		
		//Select 2008 year
		ED.Year_Options.get(2008).click();
		Thread.sleep(2000);
		
		//Select month with reusable mmethod
		ED.Select_month("Nov");
		
		//selct year with reusble method
		//ED.Select_month(options_element, ""1996);
		
		
		
		
		
	

	}

}

package pagefactory_Element_Declarations;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;

public class Element_Declations 
{
	//@findby method lok for object at webpage (this object only acess using pagefactory class)
	@FindBy(name="firstname") WebElement firstname_FB;
	
	//@findby also look for group of objects at webpage for page links
	@FindBy(tagName="a") List<WebElement> page_links;
	
	//@findby also look for group of objects at webpage 
	@FindBy(tagName="select") List<WebElement>Dropdown;
	
	//finding list of options under dropdown
	@FindBy(css="select[id='month']>option")
	List<WebElement> Month_Options;
	
	//finding list of objects under  dropdown
	@FindBy(css="select[id='year']>option")
	List<WebElement> Year_Options;
	
	
	
	
	
	/* once object is located and it will not be searched over and over again
	 * [mostly it useful in ajax web application]
	 * Note:-- sometimes we get StaleElementExceptionReference  exception
	 *   
	 */
	@FindBy(name="reg_password_") @CacheLookup WebElement password_FB;
	
	
	
	
	/*
	 * @FindBYS:  when required webelemnt match  objects need to match 
	 *   all of the given criteria
	 *   
	 */
	@FindBys({
		@FindBy(tagName="select"),        //wrong tagname
		@FindBy(tagName="input"),
		@FindBy(tagName="_8esa"),
	})List<WebElement> Bys_Group_objects;
	
	
	
	
	/*  @FindALL:when required webelement objects need to
	 * match atleast one of the given criteria 
	 */
	@FindAll({
		@FindBy(tagName="select"),                  //wrong tagname
		@FindBy(tagName="input"),
		@FindBy(tagName="_8esa"),
	})List<WebElement> Group_Objects;
	
	
	
	//reusable method for month dropdown
	public void Select_month(String monthname) 
	{
		for (WebElement eachoption : Month_Options) 
		{
			String optionname=eachoption.getText();
			if (optionname.equals(monthname))
			{
				eachoption.click();
				break;
				
			}
			
		}
	}
	
	
	
	
	//Reusable method for all dropdown options to select
	public void Select_month(List<WebElement> options_element,String Exp_options) 
	{
		for (WebElement  eachoption :options_element ) 
		{
			String optionname=eachoption.getText();
			if (optionname.equals(Exp_options))
			{
				eachoption.click();
				break;
				
			}
			
		}
	}
	

}

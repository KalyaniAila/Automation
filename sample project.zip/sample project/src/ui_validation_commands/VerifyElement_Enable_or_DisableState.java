package ui_validation_commands;

public class VerifyElement_Enable_or_DisableState 
{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

package ui_validation_commands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class IsDisplayed_for_StaticElements 
{

	public static void main(String[] args) 
	{
		
		//locate chrome browser in current system
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://www.outlook.com");
		driver.manage().window().maximize();
		
		//identify signin button
		WebElement signin_btn=driver.findElement(By.xpath("(//a[@data-task='signin'])[1]"));
		if(signin_btn.isDisplayed()) 
		{
			signin_btn.click();
			System.out.println("element is displayed");
		}
		else 
		{
			System.out.println("element not displayed");
		}
		
		//identify email location
		WebElement email=driver.findElement(By.xpath("//input[@id='i0116']"));
		if(email.isDisplayed()) 
		{
			email.clear();
			email.sendKeys("kalyaniaila199@gmail.com");
			System.out.println("element is displayed");
		}
		else 
		{
			System.out.println("element is not displayed");
		}
		
	

	}

}

package pageobjects_Pagefactory_with_constructor;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Run_FB_Reg 
{
	

	public static void main(String[] args) throws Exception 
	{
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		driver.get("https://www.facebook.com/r.php");
		driver.manage().window().maximize();
		
	    FB_REG fb_page=new FB_REG(driver);
	    fb_page.firstname_txt.sendKeys("newuser");
	    fb_page.surname_txt.sendKeys("webdriver");
	    Thread.sleep(3000);
	    fb_page.email_txt.sendKeys("newuser@2324");
	   

	}

}

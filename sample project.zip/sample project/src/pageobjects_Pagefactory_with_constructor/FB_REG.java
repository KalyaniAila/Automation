package pageobjects_Pagefactory_with_constructor;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FB_REG 
{

	public FB_REG(WebDriver driver) 
	{
		//this keyword acess current class name
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(xpath="//input[contains(@name,'firstname')]") 
	public WebElement firstname_txt;
	
	@FindBy(xpath="//input[contains(@name,'lastname')]")
	public WebElement surname_txt;
	
	@FindBy(xpath="//input[contains(@name,'reg_email__')]")
	public WebElement email_txt;

}

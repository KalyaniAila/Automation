package iteractions.touchinteractions;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.testng.annotations.AfterClass;

public class Touch_intercations_class 
{
	WebDriver driver;
	String Driver_path="Drivers\\";
	String url="https://jqueryui.com/selectable/";
	
	
  @Test
  public void testcase()
  {
	  //new TouchActions(driver).move(100, 0).perform();
		
		WebElement Element=driver.findElement(By.xpath("//li[contains(.,'Item 1')]"));
		new TouchActions(driver).singleTap(Element).perform();
		
	  
	  
  }
  
  
  @BeforeClass
  public void beforeClass() 
  {
	  System.setProperty("webdriver.chrome.driver", Driver_path+"chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.get(url);
	  driver.manage().window().maximize();
  }
  
  

  @AfterClass
  public void afterClass() throws Exception 
  {
	  Thread.sleep(3000);
	  driver.close();
  }

}

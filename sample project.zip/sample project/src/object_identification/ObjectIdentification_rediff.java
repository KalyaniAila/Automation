package object_identification;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class ObjectIdentification_rediff 
{

	public static void main(String[] args) throws Exception
	{
     System.setProperty("webdriver.chrome.driver","Drivers\\chromedriver.exe");
     WebDriver driver=new ChromeDriver();
     driver.get("https://rediff.com");
     driver.manage().window().maximize();
     
     driver.findElement(By.linkText("Create Account")).click();
     Thread.sleep(2000);
     
     //type text into editbox
     driver.findElement(By.cssSelector("*[name^='name']")).clear();
     Thread.sleep(2000);
     
     driver.findElement(By.cssSelector("*[name^='name']")).sendKeys("kalyani aila");
     driver.findElement(By.cssSelector("input[name^='login']")).sendKeys("kalyaniaila234");
     
     //click button[chect the availability] 
     driver.findElement(By.cssSelector("input[name^='btnchkavail']")).click();
     
     //type text(password) into editbox
     driver.findElement(By.cssSelector("input[name^='passwd']")).sendKeys("kalyani@12");
     driver.findElement(By.cssSelector("input[name^='confirm_passwd']")).sendKeys("kalyani@12");
     driver.findElement(By.cssSelector("input[name^='altemail']")).sendKeys("kalyaniaila1998@gmail.com");
     driver.findElement(By.cssSelector("input[name^='chk_altemail']")).click();
     
     //select dropdown with visibletext[optional]
     new Select(driver.findElement(By.cssSelector("select[name^='hintq']"))).selectByVisibleText("What is the name of your first school?");
     driver.findElement(By.cssSelector("input[name^='hinta']")).sendKeys("ZPHS");
     driver.findElement(By.cssSelector("input[name^='mothername']")).sendKeys("yadalaxmi");
     
     //driver.findElement(By.cssSelector("span[id='lbl_txt']")).sendKeys("+91");
     //driver.findElement(By.cssSelector("img[style='\"width: 10px; height: 10px;\']")).click();
     driver.findElement(By.cssSelector("input[name^='mobno']")).sendKeys("9848356348");
     
     //select dropdown 
     new Select(driver.findElement(By.cssSelector("select[name^='DOB_Day']"))).selectByVisibleText("03");
     new Select(driver.findElement(By.cssSelector("select[name^='DOB_Month']"))).selectByValue("05");
     new Select(driver.findElement(By.cssSelector("select[name^='DOB_Year']"))).selectByValue("2013");
     
   //select radio button  
     //driver.findElement(By.cssSelector("input[value='m']")).clear();
     driver.findElement(By.cssSelector("input[value='f']")).click();
     
     new Select(driver.findElement(By.cssSelector("select[name^='country']"))).selectByVisibleText("India");
     new Select(driver.findElement(By.cssSelector("select[name^='city']"))).selectByVisibleText("Agra");
     driver.findElement(By.cssSelector("input[class='captcha']")).sendKeys("N3EH");
     driver.findElement(By.cssSelector("input[name^='Register']")).click();
	}

}

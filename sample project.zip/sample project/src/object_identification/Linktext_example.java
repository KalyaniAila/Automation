package object_identification;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Linktext_example 
{

	public static void main(String[] args) throws Exception
	{
		System.setProperty("webdriver.chrome.driver","Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.navigate().to("https://www.facebook.com/");
		driver.manage().window().maximize();
		
		driver.findElement(By.linkText("Create a Page")).click();
		Thread.sleep(5000);
		
		driver.findElement(By.linkText("Forgotten account?")).click();
		
		driver.findElement(By.id("identify_email")).clear();
		driver.findElement(By.id("identify_email")).sendKeys("hello234");
	}

}

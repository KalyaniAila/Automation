package object_identification;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class IdentifyObjectWithIDproperty 
{

	public static void main(String[] args) throws Exception 
	{
		//setting runtime environment variable for chromedriver
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();   //launch browser
		driver.get("http://facebook.com");      // load webpage
		driver.manage().window().maximize();    //maximize the browser window
        
		//object identification using id property
		driver.findElement(By.id("email")).clear();
		driver.findElement(By.id("email")).sendKeys("kalyani");
		
		driver.findElement(By.id("pass")).clear();
		driver.findElement(By.id("pass")).sendKeys("hello1234");
		
		
	}

}

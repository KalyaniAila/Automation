package object_identification;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class IdentifyObjectWith_ClassProperty 
{

	public static void main(String[] args) throws InterruptedException 
	{
	  //locate chrome browser in current system 
	  System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
	  //launch browser
	  WebDriver driver=new ChromeDriver();
	  //load webpage
	  driver.get("https://outlook.com");
	  //maximaize the browser window
	  driver.manage().window().maximize();
	  
	  
	  driver.findElement(By.linkText("Sign in")).click();
	  
	  driver.findElement(By.className("form-control")).clear();
	  driver.findElement(By.className("form-control")).sendKeys("sunilreddy.gajjala@outlook.com");
	  Thread.sleep(2000);
	  
	  driver.findElement(By.className("ext-primary")).click();
	  Thread.sleep(2000);
	  
	  driver.findElement(By.className("ext-text-box")).clear();
	  driver.findElement(By.className("ext-text-box")).sendKeys("Hello123456");
	  

	}

}

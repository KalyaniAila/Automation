package object_identification;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Xpath_Attribute_And_Text_Identification 
{

	public static void main(String[] args) throws Exception 
	{
	 System.setProperty("webdriver.chrome.driver","Drivers\\chromedriver.exe");
	 WebDriver driver=new ChromeDriver();
	 driver.navigate().to("https://www.naukri.com/free-job-alerts");
	 driver.manage().window().maximize();
	 Thread.sleep(2000);
	 
	 //driver.findElement(By.xpath("//a[@class='wdgt-action-btn ']")).click();
	 driver.findElement(By.xpath("//input[@name='keyskills']")).clear();
	 driver.findElement(By.xpath("//input[@name='keyskills']")).sendKeys("software testing");
	 driver.findElement(By.xpath("//input[@id='Sug_locsugg']")).clear();
	 driver.findElement(By.xpath("//input[@id='Sug_locsugg']")).sendKeys("Hyderabad");
	 Thread.sleep(6000);
	// driver.findElement(By.xpath("//input[@id='cjaExp']")).clear();
	 driver.findElement(By.xpath("//input[@id='cjaExp']")).sendKeys("3");

	}
}

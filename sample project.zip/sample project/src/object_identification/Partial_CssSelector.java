package object_identification;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Partial_CssSelector 
{

	public static void main(String[] args) throws Exception
	{
	  System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
	  WebDriver driver=new ChromeDriver();
	  driver.get("https://facebook.com/r.php");
	  driver.manage().window().maximize();
	  
	  driver.findElement(By.cssSelector("input[id*='u_0_n']")).clear();
	  Thread.sleep(2000);
	  driver.findElement(By.cssSelector("input[id*='u_0_n']")).sendKeys("newsuser");
	  driver.findElement(By.cssSelector("input[id*='u_0_p']")).clear();
	  driver.findElement(By.cssSelector("input[id*='u_0_p']")).sendKeys("webdriver");
	  driver.findElement(By.cssSelector("input[id*='u_0_s']")).clear();
	  driver.findElement(By.cssSelector("input[id*='u_0_s']")).sendKeys("newuserwebdriver@gmail.com");
	  driver.findElement(By.cssSelector("input[id*='u_0_v']")).clear();
	  driver.findElement(By.cssSelector("input[id*='u_0_v']")).sendKeys("newuserwebdriver@gmail.com");
	  //type text into editbox
	  driver.findElement(By.cssSelector("input[id='password_step_input']")).clear();
	  driver.findElement(By.cssSelector("input[id='password_step_input']")).sendKeys("Hello2345");
	  
	  new Select(driver.findElement(By.cssSelector("select[id='day']"))).selectByVisibleText("4");
	  new Select(driver.findElement(By.cssSelector("select[id='month'"))).selectByValue("4");
	  new Select(driver.findElement(By.cssSelector("select[id='year']"))).selectByVisibleText("1995");
	  
	  driver.findElement(By.cssSelector("input[value='1']")).click();
	  Thread.sleep(2000);
	  driver.findElement(By.cssSelector("input[value='2']")).click();
	  Thread.sleep(2000);
	  driver.findElement(By.cssSelector("input[value='-1']")).click();
	  new Select(driver.findElement(By.cssSelector("select[class='_7-16 _9hk6 _5dba']"))).selectByVisibleText("She: \"Wish her a happy birthday!\"");
	  driver.findElement(By.cssSelector("input[name='custom_gender']")).sendKeys("male");
	 // driver.findElement(By.cssSelector("button[name='websubmit']")).click();
	}

}

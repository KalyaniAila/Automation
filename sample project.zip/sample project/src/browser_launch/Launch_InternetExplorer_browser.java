package browser_launch;

import org.openqa.selenium.ie.InternetExplorerDriver;

public class Launch_InternetExplorer_browser 
{

	public static void main(String[] args) 
	{
	 System.setProperty("webdriver.ie.driver", "C:\\selenium java\\sample project\\Drivers\\IEDriverServer.exe");
     InternetExplorerDriver ie=new InternetExplorerDriver();
     ie.get("http://google.com");
     System.out.println(ie.getTitle());
     ie.close();

	}

}

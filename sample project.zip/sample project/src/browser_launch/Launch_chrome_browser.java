package browser_launch;

import org.openqa.selenium.chrome.ChromeDriver;

public class Launch_chrome_browser
{

    public static void main(String args[]) 
    
	{
		System.setProperty("webdriver.chrome.driver", "C:\\selenium java\\sample project\\Drivers\\chromedriver.exe");
	    ChromeDriver chrome=new ChromeDriver();
		chrome.get("http://google.com");
		System.out.println(chrome.getTitle());
		chrome.close();
		
	}

}

package browser_launch;

import org.openqa.selenium.firefox.FirefoxDriver;

public class Launch_firefox_browser 
{

	public static void main(String[] args) throws Exception 
	{
		System.setProperty("webdriver.gecko.driver","C:\\selenium java\\sample project\\Drivers\\geckodriver.exe");
		FirefoxDriver firefox=new FirefoxDriver();
		Thread.sleep(2000);
		firefox.get("http://facebook.com");
		Thread.sleep(2000);
		System.out.println(firefox.getTitle());
		Thread.sleep(3000);
		firefox.close();
	}
	
		
}

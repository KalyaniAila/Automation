package switch_commands.frame;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Epass_FeeStructure
{

	public static void main(String[] args) throws Exception 
	{
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		driver.get("https://epass.apcfss.in/");
		//driver.manage().window().maximize();
		Thread.sleep(3000);
		
	    driver.switchTo().frame("menuFrame");
	    Thread.sleep(3000);
	    
	    WebElement Fee_structure=driver.findElement(By.xpath("//a[@href='FeestructureReport.do']"));
		Fee_structure.click();
		Thread.sleep(3000);
		
        new Select(driver.findElement(By.xpath("//a[contains(.,'Fee Structure')]"))); 
        new Select(driver.findElement(By.xpath("//select[@id='univ']"))).selectByValue("14");
		
		

	}

}

package switch_commands.Alert;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Confirm_AlertHandling_with_cancel_button 
{

	public static void main(String[] args) throws Exception 
	{
		    //setting runtime variable
	         System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		    //launching browser
		    WebDriver driver=new ChromeDriver();
			driver.get("http://demo.automationtesting.in/Alerts.html");
			driver.manage().window().maximize();
			
			WebElement AlertWith_OK_Cancel_link=driver.findElement(By.xpath("//a[@href='#CancelTab']"));
			AlertWith_OK_Cancel_link.click();
			Thread.sleep(3000);
			
			WebElement confirm_box_link=driver.findElement(By.xpath("//button[@class='btn btn-primary']"));
			confirm_box_link.click();
			Thread.sleep(3000);
			
			//switching to alert
			Alert alert=driver.switchTo().alert();
			
			//get text availabe at alert
			String alert_msg=alert.getText();
			System.out.println(alert_msg);
			
			//this command  click  CANCEL button on alert
			alert.dismiss();
			
			
			Thread.sleep(3000);
			driver.close();
			
			
			
		

	}

}

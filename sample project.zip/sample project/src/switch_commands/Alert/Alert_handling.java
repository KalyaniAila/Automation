package switch_commands.Alert;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Alert_handling
{

	public static void main(String[] args) throws Exception 
	{
		//setting runtime variable
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		//launching browser
		WebDriver driver=new ChromeDriver();
		driver.get("http://demo.automationtesting.in/Alerts.html");
		driver.manage().window().maximize();
		
		WebElement Alert_WithOK_link=driver.findElement(By.xpath("(//a[@class='analystic'])[1]"));
		Alert_WithOK_link.click();
		Thread.sleep(3000);
		
		WebElement displayAn_Alertbox=driver.findElement(By.xpath("//button[@class='btn btn-danger']"));
		displayAn_Alertbox.click();
		Thread.sleep(3000);
		
		//switching to alert and wrapped alert into interface class
		Alert alert=driver.switchTo().alert();
		
		//get text available at alert
		String alert_msg=alert.getText();
		System.out.println(alert_msg);
				

		
		//click OK button at alert 
		alert.accept();
		
		
		
		Thread.sleep(3000);
		driver.close();
		

	}

}

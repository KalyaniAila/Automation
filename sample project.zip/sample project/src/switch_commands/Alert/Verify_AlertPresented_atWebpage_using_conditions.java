package switch_commands.Alert;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class Verify_AlertPresented_atWebpage_using_conditions 
{

	public static void main(String[] args) throws Exception 
	{
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://demo.automationtesting.in/Alerts.html");
		driver.manage().window().maximize();
		
		WebElement AlertWith_OK_link=driver.findElement(By.xpath("//a[@href='#OKTab']"));
		AlertWith_OK_link.click();
		Thread.sleep(3000);
        
		WebElement Display_Alertbox_link=driver.findElement(By.xpath("//button[@class='btn btn-danger']"));
		Display_Alertbox_link.click();
		Thread.sleep(3000);
		
		//switching to alert
       // Alert alert=driver.switchTo().alert();
        //get text available at alert
        // String alert_msg=alert.getText();
         //System.out.println(alert_msg);
          //this command click  OK button at alert
         //alert.accept();
		
		if(ExpectedConditions.alertIsPresent().apply(driver)!=null) 
		{
			System.out.println("alert is presented");
		}
		else 
		{
			System.out.println("alert is not presented");
		}
	}

}


     /*       Whenever use expectectedconditions class without webdriverwait
	  *                     we should attach apply command at end of the statement
      *  
      */

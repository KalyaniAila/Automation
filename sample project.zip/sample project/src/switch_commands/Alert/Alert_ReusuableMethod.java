package switch_commands.Alert;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Alert_ReusuableMethod 
{
	static WebDriver driver;
	
	public static boolean IsAlertPresented(WebDriver driver) 
	{
		try 
		{
			driver.switchTo().alert();
			return true;
		}catch(Exception e) 
		{
			return false;
		}
	}
	
	public static void main(String[] args) throws Exception 
	{
        
		WebElement Alert_WithOK_link=driver.findElement(By.xpath("//a[@href='#OKTab']"));
		Thread.sleep(3000);
		Alert_WithOK_link.click();
		Thread.sleep(3000);
		
		WebElement displayAn_Alertbox=driver.findElement(By.xpath("//button[@class='btn btn-danger']"));
		displayAn_Alertbox.click();
		Thread.sleep(3000);
		
	   //userdefined method to verify alert presented
		if(IsAlertPresented(driver)) 
		{
			driver.switchTo().alert();
		}
		else
			System.out.println("alert not presented");
		


	}

}

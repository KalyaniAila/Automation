package switch_commands.Alert;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Alert_handling_with_sendkeys_command
{

	public static void main(String[] args) throws Exception 
	{
		//setting runtime variable
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		//launching browser
		WebDriver driver=new ChromeDriver();
		driver.get("http://demo.automationtesting.in/Alerts.html");
		driver.manage().window().maximize();
				
		WebElement Alertwith_textbox_link=driver.findElement(By.xpath("//a[@href='#Textbox']"));
	    Alertwith_textbox_link.click();
		Thread.sleep(3000);
		
		WebElement displayAn_Alertbox=driver.findElement(By.xpath("//button[@class='btn btn-info']"));
		displayAn_Alertbox.click();
		Thread.sleep(3000);
		
		//switching to alert 
		Alert alert=driver.switchTo().alert();
		
		//type text into alert textbox
		alert.sendKeys("9034422876");
		Thread.sleep(2000);
		
		//get text available at alert
		String alert_msg=alert.getText();
		System.out.println(alert_msg);
		
		//this command close alert and control back to page
		alert.accept();
		
		driver.close();

	}

}

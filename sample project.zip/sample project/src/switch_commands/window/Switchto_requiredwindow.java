package switch_commands.window;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Switchto_requiredwindow
{

	public static void main(String[] args) 
	{
	  System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
	  WebDriver driver =new ChromeDriver();
	  driver.get("https://www.cleartrip.com/trains");
	  driver.manage().window().maximize();
	  

	}

}

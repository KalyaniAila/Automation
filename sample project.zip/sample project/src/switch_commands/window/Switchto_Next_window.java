package switch_commands.window;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Switchto_Next_window 
{

	public static void main(String[] args) throws Exception 
	{
		 System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		 WebDriver driver=new ChromeDriver();
		 driver.get("https://www.facebook.com/");
		 driver.manage().window().maximize();
		 Thread.sleep(3000);
		   
		 String MainWindow_ID=driver.getWindowHandle();
		 System.out.println(MainWindow_ID);
		 Thread.sleep(3000);
	       
		 //Instagram is a hyperlink it open page at net tab/window.
		  WebElement Instagram_link=driver.findElement(By.linkText("Instagram"));
		  Instagram_link.click();
		  
		  //get all Dynamic window id's
		  Set<String> Allwindow_ID=driver.getWindowHandles();
		  System.out.println(Allwindow_ID);
		  
		  
			
		}
			
		
		  
		 
	}
	




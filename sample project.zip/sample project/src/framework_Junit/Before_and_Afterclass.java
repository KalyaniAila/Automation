package framework_Junit;


import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class Before_and_Afterclass 
{
    
	//Invoke method before execution of first @Test annotation 
	@BeforeClass
	public static void setUpBeforeClass() throws Exception
	{
		System.out.println("precondition for class");
	}
    
	//Invoke method after execution of last @Test annotation
	@AfterClass
	public static void tearDownAfterClass() throws Exception
	{
		System.out.println("post condition for class");
	}

	
	//Invoke method to run without object creation
	@Test
	public void test1() 
	{
		System.out.println("test1 run executed");
	}
	
	//Invoke method to run without object creation

	@Test
	public void test2() 
	{
		System.out.println("test2 run executed");
	}


	}

package framework_Junit;


//import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


@RunWith(Suite.class)
//@Parameters({Before_and_after.class,Myjunit_test.class,Junit_Webdriver_testcase.class})
public class Junit_testsuite_Runner
{

	@Test
	public void test() 
	{
		
	}

}

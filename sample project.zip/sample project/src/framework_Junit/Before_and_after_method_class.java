package framework_Junit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class Before_and_after_method_class 
{
    
	//Invoke method before execution of first @Test annotation
	@BeforeClass
	public static void setUpBeforeClass() throws Exception 
	{
		System.out.println("pre condition for class");
	}
    
	//Invoke method after execution of last @Test annotation
	@AfterClass
	public static void tearDownAfterClass() throws Exception
	{
		System.out.println("post condtion for class");
	}
    
	//Invoke every @Test annotated method before
	@Before
	public void setUp() throws Exception 
	{
		System.out.println("pre condtion for method");
	}
    
	//Invoke every @Test annotated method after
	@After
	public void tearDown() throws Exception 
	{
		System.out.println("post condoition for method");
	}
     
	//Invoke method to run without creation of object
	@Test
	public void test1() 
	{
      System.out.println("test1 run executed");
	}
	
	@Test
	public void test2() 
	{
		System.out.println("test2 run executed");
   
	}
	
	@Test
	public void test3() 
	{
		System.out.println("test3 run executed");
   
	}



}

package framework_Junit;


import java.io.File;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class Junit_Webdriver_testcase 
{
	static WebDriver driver;
	static String Driver_path="Drivers\\";
	static String  url="http://facebook.com";
	static String screen_path= "C:\\selenium java\\sample project\\Screens";
	
	
	// This annotation helps to get current constructed method name
    @Rule public TestName test=new TestName();
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception 
	{
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception 
	{
		Thread.sleep(3000);
		driver.close();
	}

	@Before
	public void setUp() throws Exception 
	{
		driver.get(url);
	}

	@After
	public void tearDown() throws Exception 
	{
		File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		//copy folder
		FileHandler.copy(src, new File(screen_path+test.getMethodName()+".png"));
	}

	@Test
	public void Tc001_Verify_signup_page_link()
	{
		driver.findElement(By.xpath("//img[@alt='Facebook']")).click();;
		String Exp_title="Facebook-log in or sign up ";
		Assert.assertEquals(Exp_title,driver.getTitle());
		System.out.println("sign up page verified");
		
		//WebElement fb_link=driver.findElement(By.xpath("//img[@alt='Facebook']"));
		//fb_link.click();
		//fb_link.sendKeys("kalyaniaila1998@gmail.com");
	}

	@Test
	public void Tc002_verify_Messengar_page_link() 
	{
		driver.findElement(By.xpath("//a[contains(.,'Messenger')]")).click();;
		String exp_title="Messenger";
		Assert.assertEquals(exp_title,driver.getTitle() );
		System.out.println("messenger page verifed");
		
	}
	
	@Test
	public void Tc003_verify_facebooklite_page_link() 
	{
		driver.findElement(By.xpath("//a[contains(.,'Facebook Lite')]")).click();
		String exp_title="Facebook Lite APK for Android";
		Assert.assertEquals(exp_title,driver.getTitle());
		System.out.println("facebook lite page verified");
		
	}
	
	@Test
	public void Tc004_Watch_page_link() 
	{
		driver.findElement(By.xpath("//a[@title='Browse our Watch videos.']")).click();
		String exp_title="Facebook Watch";
		Assert.assertEquals(exp_title, driver.getTitle());
		System.out.println("watch page verified");
		
	}



}

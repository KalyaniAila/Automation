package framework_Junit;


import org.junit.Test;

public class Junittest {

	@Test
	public void test() 
	{
		System.out.println("test executed");
	}

}

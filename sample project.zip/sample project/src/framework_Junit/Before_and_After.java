package framework_Junit;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class Before_and_After 
{

	@Before
	public void setUp() throws Exception
	{
		System.out.println("precondition for method");
	}

	
	@After
	public void tearDown() throws Exception 
	{
		System.out.println("post condition for method");
	}

	@Test
	public void test()
	{
		System.out.println("test run executed");
	}

}

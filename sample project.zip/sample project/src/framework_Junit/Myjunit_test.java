package framework_Junit;


import org.junit.Test;

public class Myjunit_test
{
    
	//invoke method to run without object creation
	@Test
	public void test1() 
	{
		System.out.println("test1 run executed");
	}
    
	//Invoke method to run without object creation
	@Test
	public void test2() 
	{
		System.out.println("test2 run executed");
	}

	@Test
	public void test3() 
	{
		System.out.println("test3 run executed");
	}



}

package string_numbercounts;

public class CountNumber_string {

	public static void main(String[] args) 
	{
		String string="the best of two";
		int count=0;
		
		for (int i = 0; i < string.length(); i++)             //count each chracter expect space
		{
			//if(string.charAt(i)!= '');
			count++;
			
		}
		
		System.out.println("total number of characters in a string:"+count);
		

	}

}

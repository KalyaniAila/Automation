package string_numbercounts;

public class Count_punctuation 
{

	public static void main(String args[]) 
	{
		int count=0;
		String str="I heard it with my own ears.";
		for (int i = 0; i < str.length(); i++)
		{
	  //if(str.charAt(i) == "!" || str.charAt(i) == "," || str.charAt(i) == ";" || str.charAt(i) == "." || str.charAt(i) == "?")
		     if(str.charAt(i) == '!' || str.charAt(i) == ',' || str.charAt(i) == ';' || str.charAt(i) == '.' ||  str.charAt(i) == '?' || str.charAt(i) == '-' ||    
		     str.charAt(i) == '\'' || str.charAt(i) == '\"' || str.charAt(i) == ':')   
		     {
		       count++; 
		     }
		}    

		System.out.println("the number of punctuations exists in a string:" +count);
		
	}

}



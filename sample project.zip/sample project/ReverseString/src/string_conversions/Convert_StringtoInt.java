package string_conversions;

public class Convert_StringtoInt 
{

	public static void main(String[] args) 
	{
		String str="200";
		int i = Integer.parseInt(str);                    //convert string into int
		System.out.println(i);
		

	}

}

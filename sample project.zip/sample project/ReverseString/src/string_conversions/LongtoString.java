package string_conversions;

public class LongtoString {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		long l=9988766655544L;
		String str=String.valueOf(l);
		System.out.println(str);

	}

}

package string_conversions;

public class Convert_StringtoDouble {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="23.8";
		double d=Double.parseDouble(s);
		System.out.println(d);

	}

}

package string_conversions;

public class Covert_stringto_Long 
{

	public static void main(String[] args) 
	{
		String str="980765443";
		long l=Long.parseLong(str);
		
		System.out.println(l);

	}

}

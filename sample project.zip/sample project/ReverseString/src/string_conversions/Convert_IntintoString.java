package string_conversions;

public class Convert_IntintoString
{

	public static void main(String[] args)
	{
		int i=200;
		//String str=String.valueOf(i);
		String str=Integer.toString(i);
		//String str=String.format("%d", i);
		
		System.out.println(i+100);                            //300 because + it is binary plus operator
		System.out.println(str+100);                          //200100 because + is string concatnation operator

	}

}

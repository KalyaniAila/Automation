package string_conversions;

public class Convert_StringtoChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="hello";
		//char c=s.charAt(0);                   //returns h
		//System.out.println(c);
		for (int i = 0; i <s.length(); i++)
		{
			char c=s.charAt(i);
			System.out.println("char at"+i+ "index is:" +c);
			
		}
		

	}

}

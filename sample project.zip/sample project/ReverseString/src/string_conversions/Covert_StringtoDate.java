package string_conversions;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Covert_StringtoDate {

	public static void main(String[] args) throws ParseException 
	{
		String sDate1="26/07/2021";
		Date date1=new SimpleDateFormat("dd/mm/yyyy").parse(sDate1);
		System.out.println(sDate1+"\t"+date1);
		

	}

}

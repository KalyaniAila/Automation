package string_conversions;

import java.sql.Timestamp;
import java.util.Date;

public class Convert_datetoTimestamp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date date=new Date();
		Timestamp ts=new Timestamp(date.getTime());
		System.out.println(ts);
		
		//coveting timestamp to date
		Timestamp ts1=new Timestamp(System.currentTimeMillis());
		Date d=new Date(ts1.getTime());
		System.out.println(d);

	}

}

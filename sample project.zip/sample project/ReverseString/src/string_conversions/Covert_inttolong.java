package string_conversions;

public class Covert_inttolong {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int i=100;
		//Long l=Long.valueOf(i);
		//System.out.println(l);
		
		//converting  long to int
		Long l=new Long(10);
		int i=l.intValue();
		System.out.println(i);

	}

}

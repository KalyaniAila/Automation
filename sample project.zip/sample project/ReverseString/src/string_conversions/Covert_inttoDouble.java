package string_conversions;

public class Covert_inttoDouble {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int i=100;
		//Double d=Double.valueOf(i);
		//System.out.println(d);
		
		//coverting double into int
		Double d=new Double(10.5);
		int i=d.intValue();
		System.out.println(i);

	}

}

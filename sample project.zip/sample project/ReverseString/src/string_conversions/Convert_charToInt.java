package string_conversions;

public class Convert_charToInt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//char c='1';
		//int a =Integer.parseInt(String.valueOf(c));
		//System.out.println(a);
		
		//covert int to char
		int a=65;
		char c=(char)a;
		System.out.println(c);

	}

}

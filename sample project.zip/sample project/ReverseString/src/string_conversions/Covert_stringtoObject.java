package string_conversions;

public class Covert_stringtoObject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="hello";
		Object obj=s;
		System.out.println(obj);

	}

}

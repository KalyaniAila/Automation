package string_conversions;

public class Covert_DoubletoString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double d=12.4;
		String s=String.valueOf(d);
		System.out.println(s);

	}

}

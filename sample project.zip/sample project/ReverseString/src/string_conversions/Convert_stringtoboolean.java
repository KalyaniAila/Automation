package string_conversions;

public class Convert_stringtoboolean {

	public static void main(String[] args) 
	{
		String s1="true";
		String s2="ok";
		//boolean b1=Boolean.parseBoolean(s1);
		//boolean b2=Boolean.parseBoolean(s2);
		boolean b1=Boolean.valueOf(s1);
		boolean b2=Boolean.valueOf(s2);
		System.out.println(b1);
		System.out.println(b2);
		
		boolean b3=true;
		String s3=Boolean.toString(b3);
		System.out.println(s3);


	}

}

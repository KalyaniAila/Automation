package string_conversions;

public class Covert_chartoString {

	public static void main(String[] args)
	{
		char c ='S';
		//String s=String.valueOf(c);
		String s=Character.toString(c);
		System.out.println(s);

	}

}

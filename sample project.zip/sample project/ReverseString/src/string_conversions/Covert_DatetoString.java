package string_conversions;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Covert_DatetoString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date date=Calendar.getInstance().getTime();
		DateFormat dateFormat=new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
		String strDate=dateFormat.format(date);
		System.out.println(strDate);

	}

}

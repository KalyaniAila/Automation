package string_conversions;

public class Convert_binarytoDecimal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String binarystring="1010";
		int decimal=Integer.parseInt(binarystring,2);
		System.out.println(decimal);
		
		//converting decimal to binary
		System.out.println(Integer.toBinaryString(10));
		System.out.println(Integer.toBinaryString(21));
		
		//converting hex to decimal
		String hex="a";
		int decimal1=Integer.parseInt(hex,16);
		System.out.println(decimal1);
		
		//converting decimal to hex
		System.out.println(Integer.toHexString(10));
		
		//converting octal to decimal
		String OctalString="121";
		int decimal2=Integer.parseInt(OctalString,8);
		System.out.println(decimal2);
		
		//converting decimal to octal
		System.out.println(Integer.toOctalString(8));
		
		
				

	}

}

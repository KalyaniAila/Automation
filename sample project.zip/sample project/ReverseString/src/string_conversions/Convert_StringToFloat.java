package string_conversions;

public class Convert_StringToFloat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="23.7";
		float f=Float.parseFloat(s);
		System.out.println(f);

	}

}

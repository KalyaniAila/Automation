package framework.Datadriven.PropertyFiles;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class Write_Data_to_propertyFiles {

	public static void main(String[] args) throws IOException 
	{
		
		
		//Create object for propertyFiles
		Properties obj=new Properties();
		obj.setProperty("Tc001", "Testpass");
		obj.setProperty("Tc002", "Testfail");
		obj.setProperty("Tc003", "Testpass");
		obj.setProperty("Tc004", "Testpass");
		
		
		//Create fileoutput
		String filepath="src\\framework\\Datadriven\\PropertyFiles\\Output.properties";
		FileOutputStream fo=new FileOutputStream(filepath);
		obj.store(fo, "Login Result");

	}

}

package framework.Datadriven.PropertyFiles;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Read_Data_from_propertyFiles 
{
	
	public static void main(String[] args) throws IOException
	{
		
		
		//Read File using FileInputSream\
		String filepath="src\\framework\\Datadriven\\PropertyFiles\\Input.properties";
		FileInputStream fi=new FileInputStream(filepath);
		System.out.println("file located");
		
		
		//Create object for property files
		Properties repository=new Properties();
		repository.load(fi);  //This method load entire input data to repository
		
		
		//Get Any repositry value using keyname
		String App_url=repository.getProperty("url");
		String Chrome_path=repository.getProperty("chrome.driver.path");
		
		
		System.setProperty("webdriver.chrome.driver", Chrome_path);
		WebDriver driver=new ChromeDriver();
		driver.get(App_url);
		
		
	}

}

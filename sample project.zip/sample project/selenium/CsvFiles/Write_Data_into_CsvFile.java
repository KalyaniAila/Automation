package framework.Datadriven.CsvFiles;

import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import com.opencsv.CSVWriter;

public class Write_Data_into_CsvFile 
{

	public static void main(String[] args) throws Exception 
	{
		
		
		//Create csv file
		String filepath="src\\framework\\Datadriven\\CsvFiles\\output.csv";
		FileWriter fw=new FileWriter(filepath);
		System.out.println("file created");
		
		
		//Create object for csv writer
		CSVWriter writer=new CSVWriter(fw);
		
		String Header[]= {"Usename","Password","Result"};
		writer.writeNext(Header);
		
		
		String Line1[]= {"Sunil","Hello123","Testpass"};
		String Line2[]= {"Hari","Help123","Testfail"};
		
	
		List<String []> arraylist=new ArrayList<String[]>();
		arraylist.add(Line1);
		arraylist.add(Line2);
		
		writer.writeAll(arraylist);
		

		writer.close();

	}

}

package framework.Datadriven.CsvFiles;

import java.io.FileReader;
import java.io.IOException;

import com.opencsv.CSVReader;

public class Read_Data_From_CsvFiles {

	public static void main(String[] args) throws IOException
	{
		
		
		//Target file location using filereader
		String filepath="src\\framework\\Datadriven\\CsvFiles\\input.csv";
		FileReader fr=new FileReader(filepath);
		System.out.println("file located");
		
		//Create object for csvreader
		CSVReader reader=new CSVReader(fr);
		
		//THis command read first line of file and stored values into array
		String header[]=reader.readNext();
		System.out.println(header[0]+"   "+header[1]);
		
		//Read Next line at file
		String Line1[]=reader.readNext();
		System.out.println(Line1[0]+"     "+Line1[1]);
		
		
		
		String Line[];
		while((Line=reader.readNext())!=null)
		{
			System.out.println(Line[0]+"   "+Line[1]);
		}
		
	}

}

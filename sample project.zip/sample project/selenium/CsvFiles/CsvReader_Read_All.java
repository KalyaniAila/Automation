package framework.Datadriven.CsvFiles;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import com.opencsv.CSVReader;

public class CsvReader_Read_All {

	public static void main(String[] args) throws IOException {
		
		
		//Target file location using filereader
		String filepath="src\\framework\\Datadriven\\CsvFiles\\input.csv";
		FileReader fr=new FileReader(filepath);
		System.out.println("file located");
		
		//Create object for csvreader
		CSVReader reader=new CSVReader(fr);
		

		//THis command read first line of file and stored values into array
		String header[]=reader.readNext();
		System.out.println(header[0]+"   "+header[1]);
		
		
		//It read all records in flat file and store into list interface
		List<String[]> all_records=reader.readAll();
		
		for (String[] EachRecord : all_records) 
		{
			System.out.println(EachRecord[0]+"     "+EachRecord[1]);
		}
		
	
		
		
		
	}

}

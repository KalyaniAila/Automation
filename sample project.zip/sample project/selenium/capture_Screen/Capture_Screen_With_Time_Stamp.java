package capture_Screen;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class Capture_Screen_With_Time_Stamp {

	public static void main(String[] args) throws Exception {
	

		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.naukri.com/free-job-alerts");
		driver.manage().window().maximize();
		
		
		//Get Default system time
		Date d=new Date();
		//Crate simple date format
		DateFormat df=new SimpleDateFormat("yyyy-MMM-dd-hh-mm-ss");
		//Convert Default date using dateformatter
		String time=df.format(d);
		
		
		//Capture screen at automation browser and convert into file format
		File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		//Create folder under project
		FileHandler.createDir(new File("Screens"));
		//Copy file to folder
		FileHandler.copy(src, new File("Screens\\Image"+time+".Png"));
		

	}

}

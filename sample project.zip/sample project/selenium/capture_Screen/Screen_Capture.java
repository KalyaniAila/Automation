package capture_Screen;

import java.io.File;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class Screen_Capture {

	public static void main(String[] args) throws Exception
	{
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.naukri.com/free-job-alerts");
		driver.manage().window().maximize();
		
		//Capture screen at automation browser and convert into file format
		File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		//Create folder under project
		FileHandler.createDir(new File("Screens"));
		//Copy file to folder
		FileHandler.copy(src, new File("Screens\\Image.Png"));
		
		/*
		 * Disadvantages:-->
		 * 			=> capture only visible interface of screen
		 * 			=> Can't capture screen when alert presented
		 * 			=> Every time code executed it override image
		 * 
		 * 			Note:--> In selenium4 beta version it hhcaptue
		 * 					screen of entire page..
		 */
		

	}

}

package capture_Screen;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Dump_Screen_With_FileUtils 
{

	public static void main(String[] args) throws Exception 
	{
		
		/*
		 * Inorder to user fileutils class we must downlaod
		 * and configure commonio jar file to current project
		 * 
		 * 	URL:-->https://mvnrepository.com/artifact/commons-io/commons-io/2.8.0
		 * 			Click on Jar file to download
		 * 			And then configure jar file to current project
		 * 
		 */
		
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.naukri.com/free-job-alerts");
		driver.manage().window().maximize();
		
		
		//Get Default system time
		Date d=new Date();
		//Crate simple date format
		DateFormat df=new SimpleDateFormat("yyyy/MMM/dd/ hh-mm-ss");
		//Convert Default date using dateformatter
		String time=df.format(d);
		
		
		File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
 
		
		/*
		 * Note:--> In timestamp  forward slash create folder.
		 * 			It only works when fileutils used to dump a screen shot
		 */
		
		

	}

}

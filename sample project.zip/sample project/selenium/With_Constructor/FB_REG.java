package pageobjects.pageFactory.With_Constructor;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FB_REG 
{

	public FB_REG(WebDriver driver) 
	{
		PageFactory.initElements(driver, this);  //This keyword access current class name
	}
	
	
	
	@FindBy(xpath = "//input[@name='firstname']")
	public WebElement Firstname_txt;
	
	@FindBy(xpath = "//input[@name='lastname']")
	public WebElement Surname_txt;
	
	@FindBy(xpath = "//input[@name='reg_email__']")
	public WebElement Email_txt;

}

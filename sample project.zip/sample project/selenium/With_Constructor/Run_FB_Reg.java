package pageobjects.pageFactory.With_Constructor;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class Run_FB_Reg {

	public static void main(String[] args)
	{
		
		
		
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://www.facebook.com/r.php");
		
		
		FB_REG fbreg=new FB_REG(driver);
		fbreg.Firstname_txt.sendKeys("Newuser");
		fbreg.Surname_txt.sendKeys("webdriver");
		
		
		
		

	}

}

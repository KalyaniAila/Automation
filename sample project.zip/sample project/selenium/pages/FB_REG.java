package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FB_REG 
{

	public FB_REG(WebDriver driver) 
	{
		PageFactory.initElements(driver, this);  //This keyword access current class name
	}
	
	public String fb_pageurl="https://www.facebook.com/reg/?rs=7";
	

	@FindBy(xpath = "//input[@name='firstname']")
	public WebElement Firstname_txt;
	
	@FindBy(xpath = "//input[@name='lastname']")
	public WebElement Surname_txt;
	
	@FindBy(xpath = "//input[@name='reg_email__']")
	public WebElement Email_txt;
	
	@FindBy(xpath = "//select[@id='day']")
	public WebElement Dropdownn_Day;
	
	@FindBy(xpath = "//select[@id='month']")
	public WebElement Dropdownn_month;
	
	@FindBy(xpath = "//select[@id='year']")
	public WebElement Dropdownn_year;
	
	@FindBy(xpath = "//input[@value='2']")
	public WebElement male_rbtn;
	
	@FindBy(xpath = "//input[@value='1']")
	public WebElement Female_rbtn;

}

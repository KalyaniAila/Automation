package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Naukri_Menu_Buttons 
{
	WebDriver driver;

	public Naukri_Menu_Buttons(WebDriver driver) 
	{
		PageFactory.initElements(driver, this);
		this.driver=driver;
	}
	
	
	@FindBy(xpath = "//div[@class='mTxt'][contains(.,'Jobs')]")
	public WebElement MainMenu_jobs;
	
	@FindBy(xpath = "//a[@data-ga-track='Main Navigation Jobs|Search Jobs']")
	public WebElement Jobs_Search_jobs;
	
	@FindBy(xpath = "//a[@data-ga-track='Main Navigation Jobs|Register Now']")
	public WebElement Jobs_Register_now;

}

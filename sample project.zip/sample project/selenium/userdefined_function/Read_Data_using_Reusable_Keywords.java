package framework.Datadriven.Excel.userdefined_function;

public class Read_Data_using_Reusable_Keywords {

	public static void main(String[] args) 
	{
		
		
		Excel_Reusable_keywords obj=new Excel_Reusable_keywords();
		obj.ReadFile("InputBook.xlsx", "Sheet1");
		String UID=obj.getStringCelldata(1, 1);
		System.out.println(UID);
		
		obj.ReadFile("InputBook.xlsx", "Numerics");
		String MobileNumber=obj.Read_NumericCell_In_String_format(1, 4);
		System.out.println(MobileNumber);
		
		//Write cell data to excel
		obj.WriteCell_Data(1, 5, "Testpass");
		obj.Create_Excel_output_file("OP.xlsx");

	}

}

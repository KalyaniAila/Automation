package api_testing;

import java.net.HttpURLConnection;
import java.net.URL;

public class Check_GetConnection 
{
	
	public static boolean Verify_Get_Connection(String urlString, int Exp_status) throws Exception
	{
		
		 URL u = new URL(urlString);
         HttpURLConnection h = (HttpURLConnection)u.openConnection();
         h.setRequestMethod("GET");
         h.connect();
         int Response_code=h.getResponseCode();
        
        
        
        System.out.println("Response code is ---> "+Response_code);
        if(Response_code==Exp_status)
        {
        	return true;
        }
        else
        {
        	return false;
        }
	}
	
	

	public static void main(String[] args) throws Exception 
	{
		
		boolean flag=Verify_Get_Connection("https://facebook.com",200);
		System.out.println("Return status is ---> "+flag);
		
		

	}

}

package framework.Junit;

import java.io.File;
import java.util.concurrent.TimeUnit;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class Junit_WebDriver_Testcase 
{
	static WebDriver driver;
	static String Driver_path="Drivers\\";
	static String url="http://facebook.com";
	static String screen_path="C:\\Users\\MINDQ\\Desktop\\6PM_2021_5th_Jan\\Project_185\\TestData\\";
	
	//This annotation helps to get current constructed method name
	@Rule public TestName test=new TestName();
	
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception 
	{
		System.setProperty("webdriver.chrome.driver", Driver_path+"chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception
	{
		Thread.sleep(5000);
		driver.close();
	}

	@Before
	public void setUp() throws Exception
	{
		driver.get(url);
	}

	@After
	public void tearDown() throws Exception 
	{
		File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileHandler.copy(src, new File(screen_path+test.getMethodName()+".png"));
	}
	
	

	@Test
	public void Tc001_Verify_signup_page_link() 
	{
		driver.findElement(By.xpath("//a[@title='Sign up for Facebook']")).click();
		String Exp_title="Sign up for Facebook | Facebook";
		Assert.assertEquals(Exp_title, driver.getTitle());
		System.out.println("Signup page verified");
	}
	
	
	@Test
	public void Tc002_Verify_signIn_page_link() 
	{
		driver.findElement(By.xpath("//a[@href='/login/']")).click();
		String Exp_title="Log in to Face";
		Assert.assertEquals(Exp_title, driver.getTitle());
		System.out.println("Login page verified");
	}
	
	

	@Ignore
	public void Tc003_Verify_Messenger_page_link() 
	{
		driver.findElement(By.xpath("//a[@href='https://messenger.com/']")).click();
		String Exp_title="Messenger";
		Assert.assertEquals(Exp_title, driver.getTitle());
		System.out.println("Messenger page verified");
	}
	
	

	@Test
	public void Tc004_Verify_Facebook_Lite_page_link() 
	{
		driver.findElement(By.xpath("//a[@href='/lite/']")).click();
		String Exp_title="Facebook Lite APK for Android";
		Assert.assertEquals(Exp_title, driver.getTitle());
		System.out.println("Facebook lite  page verified");
	}
	
	
	

}

package framework.Junit;


import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class Before_And_AfterClass 
{

	@Test
	public void test1() 
	{
		System.out.println("Test1 Executed");
	}
	
	@Test
	public void test2() 
	{
		System.out.println("Test2 Executed");
	}
	

	@BeforeClass//Invoke method before execution of first @Test annotation
	public static void setUpBeforeClass() throws Exception 
	{
		System.out.println("precondition for class");
	}

	@AfterClass//Invoke method after execution of last @Test annotation
	public static void tearDownAfterClass() throws Exception 
	{
		System.out.println("Post condition for class");
	}



}

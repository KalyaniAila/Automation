package framework.Junit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class Before_And_After 
{
	
	@Test
	public void test1() 
	{
		System.out.println("Test1 Executed");
	}
	
	@Test
	public void test2() 
	{
		System.out.println("Test2 Executed");
	}
	
	@Test
	public void test3() 
	{
		System.out.println("Test3 Executed");
	}

	@BeforeClass
	public static void setUpBeforeClass() throws Exception 
	{
		System.out.println("PreCondition for class");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception
	{
		System.out.println("Post Condition for Class");
	}

	@Before//Invoke every @Test annotated method before
	public void setUp() throws Exception 
	{
		System.out.println("PreCondition for Each Method");
	}

	@After //Invoke Every @Test annorated method after
	public void tearDown() throws Exception 
	{
		System.out.println("Post Condition for each method");
	}


}

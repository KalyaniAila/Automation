package framework.Junit;

import org.junit.Test;

public class Myjunit_Test 
{

	@Test  //Invoke method to run without object creation
	public void test1() 
	{
		System.out.println("test1 run executed");
	}
	
	
	//@Test  //Invoke method to run without object creation
	public void test2() 
	{
		System.out.println("test2 run executed");
	}
	
	 @Test
	public void test3() 
	{
		System.out.println("test3 run executed");
	}
	

}

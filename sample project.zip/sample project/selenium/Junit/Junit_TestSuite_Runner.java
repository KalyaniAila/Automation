package framework.Junit;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({Before_And_After.class,
	Myjunit_Test.class,
	Junit_WebDriver_Testcase.class})
public class Junit_TestSuite_Runner 
{
	
}

package pageobjects.pageFactory.With_Global_Constructor;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class OL_SignIn 
{

	WebDriver driver;

	public OL_SignIn(WebDriver driver) 
	{
		this.driver=driver;
	}
	
	
	
	@FindBy(xpath = "(//a[@data-task='signin'])[1]")
	public WebElement Signin_nav_btn;
	
	@FindBy(xpath = "//input[@id='i0116']")
	public WebElement Email_text;
	
	
	
	public void verify_title()
	{
		String Page_title=driver.getTitle();
		System.out.println(Page_title);
	}

}

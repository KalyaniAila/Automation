package pageobjects;

import org.openqa.selenium.By;

public class PAGE_FB_HOME 
{
	
	/*
	 * public modifier allowed variable to access outside package as well
	 * static is usefull to get object outside class without obeject cration,
	 *  Only by using classname
	 */
	
	public static By Login_email_txt=By.xpath("//input[contains(@data-testid,'email')]");
	public static By Login_Password_txt=By.xpath("//input[contains(@data-testid,'royal_pass')]");
	public static By Login_login_btn=By.xpath("//button[contains(@data-testid,'button')]");
	public static By Forgot_password_link=By.xpath("//a[contains(.,'Forgotten password?')]");

	
	
	//Input Data
	public static String page_url="http://facebook.com";
	public static String exp_title="Facebook � log in or sign up";
	public static String username="qadarshan";
	public static String password="hello@123";
	public static String Login_Err_msg="";
	
	
}

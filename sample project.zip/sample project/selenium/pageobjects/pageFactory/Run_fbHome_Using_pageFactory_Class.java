package pageobjects.pageFactory;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;


public class Run_fbHome_Using_pageFactory_Class {

	public static void main(String[] args) throws Exception 
	{
		
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("http://facebook.com");
		
		
		/*
		 * INorder to call @Find by method in different class, we shuold create
		 * pagefactory class object...
		 */
		FB_HOME fb_page=PageFactory.initElements(driver, FB_HOME.class);
		fb_page.User_login("Darshan", "Hello1234");
		
		//Testcase with Empty password
		Thread.sleep(5000);
		fb_page.Enter_email("sunil");
		fb_page.CLick_login_btn();
		
		//Verify object is visible at webpage
		boolean flag=fb_page.login_email.isDisplayed();
		System.out.println("Object visible status is --> "+flag);

	}

}

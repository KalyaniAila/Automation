package pageobjects.pageFactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class FB_HOME
{
	
	
	@FindBy(id="email") 
	public WebElement login_email;
	
	@FindBy(xpath = "//input[@data-testid='royal_pass']") 
	public WebElement login_passord;
	
	@FindBy(xpath="//button[@name='login']")
	public WebElement login_submit_btn;
	
	
	
	
	public void Enter_email(String uid)
	{
		login_email.clear();
		login_email.sendKeys(uid);
	}
	
	public void Enter_password(String pwd)
	{
		login_passord.clear();
		login_passord.sendKeys(pwd);
	}
	
	
	public void CLick_login_btn()
	{
		login_submit_btn.click();
	}
	
	
	public void User_login(String username,String password)
	{
		Enter_email(username);
		Enter_password(password);
		CLick_login_btn();
	}
	
	
	
	

}

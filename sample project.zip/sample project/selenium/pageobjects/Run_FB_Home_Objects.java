package pageobjects;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Run_FB_Home_Objects {

	public static void main(String[] args) 
	{
		
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		driver.get(PAGE_FB_HOME.page_url);
		
	
		if(driver.getTitle().equals(PAGE_FB_HOME.exp_title))
		{
			WebElement UID_Element=driver.findElement(PAGE_FB_HOME.Login_email_txt);
			UID_Element.clear();
			UID_Element.sendKeys(PAGE_FB_HOME.username);
			
			WebElement PWD_Element=driver.findElement(PAGE_FB_HOME.Login_Password_txt);
			PWD_Element.clear();
			PWD_Element.sendKeys(PAGE_FB_HOME.password);
			
			
		}
		else
			System.out.println("Wrong title presnted for fb homepage");
		
		
		

	}

}

package pageobjects.pageobjects.pageFactory;

import org.testng.annotations.Test;

import pageobjects.pageFactory.FB_HOME;

import org.testng.annotations.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;

public class Run_PageObjects_Using_Testng_Class 
{
	
  WebDriver driver;
  FB_HOME fb_page;
  
  
  
  @Test(priority=0)
  public void Verify_Email_Visible() 
  {
	  Assert.assertTrue(fb_page.login_email.isDisplayed());
	  Reporter.log("username visible at webapge");
  }
  
  
  @Test(priority=1)
  public void Login_with_invalid_password() 
  {
	  fb_page.User_login("qadarshan", "123@123");
  }
  

  
  @BeforeClass
  public void beforeClass() 
  {
	  System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.get("http://facebook.com");
	  driver.manage().window().maximize();
	  fb_page=PageFactory.initElements(driver, FB_HOME.class);
  }

  @AfterClass
  public void afterClass() throws Exception 
  {
	  Thread.sleep(500);
	  driver.close();
  }

}

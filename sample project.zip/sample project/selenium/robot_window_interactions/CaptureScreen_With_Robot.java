package robot_window_interactions;

import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class CaptureScreen_With_Robot {

	public static void main(String[] args) throws Exception 
	{
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://swisnl.github.io/jQuery-contextMenu/demo.html");
		driver.manage().window().maximize();
		
		
		WebElement Context_Element=driver.findElement(By.xpath("//span[.='right click me']"));
		
		//Create object for actions class
		Actions action=new Actions(driver);
		action.contextClick(Context_Element).perform();
		
		
		WebElement Delete_btn=driver.findElement(By.xpath("//span[.='Delete']"));
		Delete_btn.click();  //This action prompt alert
		Thread.sleep(4000);
		
		
		//Get System Dimension
		Dimension ScreenSize=Toolkit.getDefaultToolkit().getScreenSize();
		
		//Create Rectangel screen using dimension
		Robot robot=new Robot();
		BufferedImage Screen_img=robot.createScreenCapture(new Rectangle(ScreenSize));
		
		//Write Image into Local Files
		//ImageIO.write(BufferdImagename, "ImageExtension", path of file"));
		File path=new File("D:\\Screens\\img.png");
		ImageIO.write(Screen_img, "PNG", path);
		
		

	}

}

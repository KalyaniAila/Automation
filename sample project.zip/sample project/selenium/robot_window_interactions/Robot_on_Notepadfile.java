package robot_window_interactions;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

public class Robot_on_Notepadfile
{

	public static void main(String[] args) throws IOException, InterruptedException, Exception 
	{
		
		Runtime.getRuntime().exec("notepad.exe");
		Thread.sleep(5000);
		
		//Create Robot object
		Robot robot=new Robot();
		robot.setAutoDelay(500);  
		
		//Type hello friends text into Notepad file
		robot.keyPress(KeyEvent.VK_H);
		robot.keyPress(KeyEvent.VK_E);
		robot.keyPress(KeyEvent.VK_L);
		robot.keyPress(KeyEvent.VK_L);
		robot.keyPress(KeyEvent.VK_O);
		
		robot.keyPress(KeyEvent.VK_TAB);
		
		robot.keyPress(KeyEvent.VK_F);
		robot.keyPress(KeyEvent.VK_R);
		robot.keyPress(KeyEvent.VK_I);
		robot.keyPress(KeyEvent.VK_E);
		robot.keyPress(KeyEvent.VK_N);
		robot.keyPress(KeyEvent.VK_D);
		robot.keyPress(KeyEvent.VK_S);
		

	}

}

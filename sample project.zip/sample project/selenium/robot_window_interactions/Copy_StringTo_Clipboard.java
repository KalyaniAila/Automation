package robot_window_interactions;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

public class Copy_StringTo_Clipboard 
{

	public static void main(String[] args) throws Exception 
	{
		
		
		String text="Tell us what kind of a job you are looking out for and stay updated with latest opportunities.";
	
		//Copy String
		StringSelection stext=new StringSelection(text);
		//Get System Clipboard
		Clipboard clipboard=Toolkit.getDefaultToolkit().getSystemClipboard();
		//Copy selected string to clipboard
		clipboard.setContents(stext, stext);
		
		
		//Create Notepad file at runtime
		Runtime.getRuntime().exec("notepad.exe");
		Thread.sleep(3000);
		
		//Create object for Robot
		Robot robot=new Robot();
		robot.setAutoDelay(2000);
		
		
		//To paste Copied text at notepad file...
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		
	
		//Save Notepad file  [Control+S]
		robot.keyPress(KeyEvent.VK_S);
		
		//Copy Text to clipboard
		String Path="C:\\Users\\MINDQ\\Desktop\\robottext.txt";
		StringSelection spath=new StringSelection(Path);
		clipboard.setContents(spath, spath);
		
		//Paste text into Window path location  [Control+V]
		robot.keyPress(KeyEvent.VK_V);
		//Press Ener
		robot.keyPress(KeyEvent.VK_ENTER);
		
		//Release Control 
		robot.keyRelease(KeyEvent.VK_CONTROL);
				
		
		
		
		
		
		

	}

}

package framework.Testng;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class My_Testng_test 
{
  @Test
  public void test1() 
  {
	  Reporter.log("Test1 executed");
  }
}

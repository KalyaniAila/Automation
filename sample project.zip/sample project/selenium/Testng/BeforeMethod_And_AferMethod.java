package framework.Testng;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;

public class BeforeMethod_And_AferMethod
{
	
	
  @Test
  public void tc001() 
  {
	  Reporter.log("Tc001 executed ",true);
  }
  
  @Test
  public void tc002() 
  {
	  Reporter.log("Tc002 executed",true);
  }
	  
	 
  @BeforeMethod
  public void beforeMethod() 
  {
	  System.out.println("PreConditon for Method");
  }

  @AfterMethod
  public void afterMethod() 
  {
	  System.out.println("postConditon for method"+"\n");
  }

}

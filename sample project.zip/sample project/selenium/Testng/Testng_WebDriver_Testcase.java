package framework.Testng;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import java.io.File;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;

public class Testng_WebDriver_Testcase {

	 WebDriver driver;
	 String Driver_path="Drivers\\";
	 String url="http://facebook.com";
	 String screen_path="C:\\Users\\MINDQ\\Desktop\\6PM_2021_5th_Jan\\Project_185\\TestData\\";
	
	
	@Test
	public void Tc001_Verify_signup_page_link() 
	{
		driver.findElement(By.xpath("//a[@title='Sign up for Facebook']")).click();
		String Exp_title="Sign up for Facebook | Facebook";
		Assert.assertEquals(driver.getTitle(), Exp_title);
		Reporter.log("singup page verified presented with title --> "+driver.getTitle(),true);
	}
	
	
	@Test
	public void Tc002_Verify_signIn_page_link() 
	{
		driver.findElement(By.xpath("//a[@href='/login/']")).click();
		String Exp_title="Log in to Face";
		Assert.assertEquals(driver.getTitle(), Exp_title);
		Reporter.log("Login page verified presented with title --> "+driver.getTitle());
	}
	
	

	@Test
	public void Tc003_Verify_Messenger_page_link() 
	{
		driver.findElement(By.xpath("//a[@href='https://messenger.com/']")).click();
		String Exp_title="Messenger";
		Assert.assertEquals(driver.getTitle(), Exp_title);
		Reporter.log("Messenger verified presented with title --> "+driver.getTitle());
	}
	
	
''
	@Test
	public void Tc004_Verify_Facebook_Lite_page_link() 
	{
		driver.findElement(By.xpath("//a[@href='/lite/']")).click();
		String Exp_title="Facebook Lite APK for Android";
		Assert.assertEquals(driver.getTitle(), Exp_title);
		Reporter.log("Facebook Lite page verified presented with title --> "+driver.getTitle());
	}
	
  

  @BeforeMethod
  public void beforeMethod() 
  {
	  driver.get(url);
  }

  @AfterMethod  //Method Parameter allow to access current constructed @Test method name
  public void afterMethod(Method method) throws Exception
  {
	    File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileHandler.copy(src, new File(screen_path+method.getName()+".png"));
  }

  @BeforeClass
  public void beforeClass()
  {
	  System.setProperty("webdriver.chrome.driver", Driver_path+"chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
  }

  @AfterClass
  public void afterClass() throws Exception 
  {
	  Thread.sleep(5000);
	  driver.close();
  }

}

package framework.Testng;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;

public class BeforeClass_And_AfterClass 
{
  @Test
  public void f() 
  {
	  Reporter.log("f method executed ",true);
  }
  @BeforeClass
  public void beforeClass() 
  {
	  System.out.println("PreCondition for class");
  }

  @AfterClass
  public void afterClass() 
  {
	  System.out.println("PostCondition for Class");
  }

}

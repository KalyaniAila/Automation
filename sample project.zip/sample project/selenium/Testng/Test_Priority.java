package framework.Testng;

import org.testng.annotations.Test;

public class Test_Priority 
{
  @Test(priority=0)
  public void f() 
  {
	  
  }
  
  @Test(priority=1)
  public void b() 
  {
	  
  }
  
  @Test(priority=2)
  public void a() 
  {
	  
  }
}

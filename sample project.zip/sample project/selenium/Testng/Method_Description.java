package framework.Testng;

import org.testng.annotations.Test;

public class Method_Description 
{
	
	
  @Test(priority=0,description="Verifying login with valid data")
  public void tc001() 
  {
	  
  }
  
  
  @Test(priority=1,enabled=false,description="verifying login with invalid data")
  public void tc002() 
  {
	  
  }
  
  
  @Test
  public void tc003() 
  {
	  
  }
  
}

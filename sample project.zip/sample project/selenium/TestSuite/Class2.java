package framework.Testng.TestSuite;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class Class2 
{
	
	@Test
	public void tc004()
	{
		Reporter.log("tcoo4 executed");
	}
	
	@Test
	public void tc005()
	{
		Reporter.log("tcoo5 executed");
	}
	
	
	@Test
	public void tc006()
	{
		Reporter.log("tcoo6 executed");
	}
 
}

package findelements.webtable;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Read_Speific_Row_From_DynamicRows_Using_ReferrenceText {

	public static void main(String[] args) 
	{
		
		/*
		 * FAQ:--> Read data from dynamic row based of reference text..
		 */
		
		
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://www.icicidirect.com/equity");
		driver.manage().window().maximize();
		
		
		
		//Target table
		WebElement table=driver.findElement(By.id("tblMarketToday"));
		
		//Find list of dynamic rows available at table
		List<WebElement> rows=table.findElements(By.tagName("tr"));
		rows.remove(0);  //This command remove table headers row
		System.out.println("Number of Rows data avaialble in table--> "+rows.size());
		
		
		//Apply foreach loop
		for (WebElement Eachrow : rows) 	
		{
			
			//Condition To target SPecific rocord in each row
			String Row_Text=Eachrow.getText();
			
			//Condition to verify partial text at each row..
			if(Row_Text.contains("Tata Steel"))
			{
				
				
				//Finding list of cell in each dynamic row..
				List<WebElement> Cells=Eachrow.findElements(By.tagName("td"));
				String CompanyName=Cells.get(0).getText();
				String LTP=Cells.get(1).getText();
				String Gain=Cells.get(2).getText();
				String Volume=Cells.get(3).getText();
				String Turnover=Cells.get(4).getText();
				
				System.out.println(CompanyName+"\t"+LTP+"\t"+Gain+"\t"+Volume+"\t"+Turnover);
				break;  //Stop iteration once expected found
			}
			
			
		}
		
		
		

	}

}

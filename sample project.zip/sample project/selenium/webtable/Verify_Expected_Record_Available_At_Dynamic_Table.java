package findelements.webtable;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Verify_Expected_Record_Available_At_Dynamic_Table {

	public static void main(String[] args) 
	{
		
		

		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://www.icicidirect.com/equity");
		driver.manage().window().maximize();
		
		
		
		//Target table
		WebElement table=driver.findElement(By.id("tblMarketToday"));
		
		//Find list of dynamic rows available at table
		List<WebElement> rows=table.findElements(By.tagName("tr"));
		rows.remove(0);  //This command remove table headers row
		System.out.println("Number of Rows data avaialble in table--> "+rows.size());
		
		boolean record_status=false;
		//Apply foreach loop
		for (WebElement Eachrow : rows) 	
		{
			
			//Condition To target SPecific rocord in each row
			String Row_Text=Eachrow.getText();
			
			//Condition to verify partial text at each row..
			if(Row_Text.contains("Tata Steel"))
			{
				record_status=true;
				
			}
			
			
		}
		
		System.out.println("Record available status is ---> "+record_status);
		
		
		
		
		//Easy method to verify text available at table
		boolean flag=table.getText().contains("Tata Steel");
		System.out.println("record available status is ---> "+flag);

	}

}

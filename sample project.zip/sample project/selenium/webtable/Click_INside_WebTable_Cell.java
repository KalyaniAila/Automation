package findelements.webtable;

import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Click_INside_WebTable_Cell {

	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://www.icicidirect.com/equity/index/overview");
		driver.manage().window().maximize();
		
		
		
		WebElement Next_button=driver.findElement(By.id("tblIdxMoment_next"));
		
		boolean flag=false;
		String Exp_Recordname="XYZ";
		boolean Record_status=false;
		do {
			
			//Target Table Location at webpage
			WebElement Table=driver.findElement(By.xpath("//table[@id='tblIdxMoment']/tbody"));
			//Get all Rows inside table
			List<WebElement> rows=Table.findElements(By.tagName("tr"));
			System.out.println(rows.size());
			//Iterate for number or rows
			for (WebElement Eachrow : rows) 
			{
				
				 //Find list of cell under each row
				List<WebElement> cells=Eachrow.findElements(By.tagName("td"));
				String ShareName=cells.get(0).getText();
				if(ShareName==Exp_Recordname)
				{
					cells.get(0).findElement(By.linkText(Exp_Recordname)).click();
					System.out.println("Clicked Iside cell");
					Record_status=true;
					break; //It stop for loop [inner loop]iteration
				}
			}
			
			if(Record_status==true)
			{
				break;  //This command break do while [Outter loop]
			}
		
			
		

			//Get Runtime attribute value
			Next_button=driver.findElement(By.id("tblIdxMoment_next"));
			String Next_btn_runtime_class=Next_button.getAttribute("class");
			flag=Next_btn_runtime_class.contains("disabled");
			
			if(flag==false)
			{
				Next_button.click();
				System.out.println("Next button clicked");
			}
			
		} while (flag==false);   //When Next button get disable it stop iteration
		
		
		
		
		//Condition to target ON Record found
		boolean index_Record=false;
		if(Record_status==true)
		{
			WebElement Index_Table=driver.findElement(By.id("tblIndexConst"));
			if(Index_Table.getText().contains("Bharat Electronics Ltd"))
			{
				index_Record=true;
			}
		}
		
		System.out.println("index Record available status is ---> "+index_Record);
		

	}

}

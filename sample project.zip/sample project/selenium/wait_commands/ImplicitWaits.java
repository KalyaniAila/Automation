package wait_commands;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ImplicitWaits 
{

	public static void main(String[] args) {
		
		
		//Set Runtime environment variable for chrome driver
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");    
		WebDriver driver=new ChromeDriver();
		
		//Manage all implicit waits at once...
		driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS)
		.pageLoadTimeout(100, TimeUnit.SECONDS)
		.setScriptTimeout(50, TimeUnit.SECONDS);
		
		
		
		driver.get("https://www.google.com/");
		driver.manage().window().maximize();
		
		

	}

}

package wait_commands;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ImplicitWait {

	public static void main(String[] args) 
	{
		
		
		//Set Runtime environment variable for chrome driver
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");    
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
		driver.get("https://www.google.com/");
		driver.manage().window().maximize();
		
		
		long Start_time=System.currentTimeMillis();
		long End_time;
		
		try {
			driver.findElement(By.id("email"));
			End_time=System.currentTimeMillis();
			System.out.println("Object identified for facebook");
			
			driver.findElement(By.id("FromTag"));
			System.out.println("Object identified  for cleartrip");
			
			
		} catch (NoSuchElementException e) {
			End_time=System.currentTimeMillis();
		}
		
		System.out.println(End_time-Start_time);
		
				

	}

}

package wait_commands;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Explicitwati_Systamx {

	public static void main(String[] args) {
		
		//Set Runtime environment variable for chrome driver
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");    
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
		driver.get("https://www.selenium.dev");
		driver.manage().window().maximize();
		
		
		
		//Enable Explicit wait timeout on automation browser
		WebDriverWait wait=new WebDriverWait(driver, 50);
		
		//Manage timegap until expected title load
		String Exp_title="SeleniumHQ Browser Automation";
		wait.until(ExpectedConditions.titleIs(Exp_title));
		
		System.out.println("Expected title presented");
		
		

	}

}

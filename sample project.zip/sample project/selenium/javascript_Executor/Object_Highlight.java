package javascript_Executor;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Object_Highlight 
{

	public static void main(String[] args)
	{
		
		//Set Runtime environment variable for chrome driver
		System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");    
		//browser initiation command
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com/r.php");
		driver.manage().window().maximize();
		
		
		//Chaging object background color to yello
		WebElement Month_dropdown=driver.findElement(By.id("month"));
		((JavascriptExecutor)driver)
		.executeScript("arguments[0].style.backgroundColor='yellow'",Month_dropdown);

		
		//Setting outline to object 
		WebElement Header=driver.findElement(By.xpath("(//div[contains(.,'Create a new account')])[7]"));
		((JavascriptExecutor)driver)
		.executeScript("arguments[0].style.outline='red solid 2px'",Header);

		
		
		
		
	}

}

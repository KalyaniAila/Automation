package framework.Testng.DataProvider;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;

public class SampleData 
{
	
  @Test(dataProvider = "userdata")
  public void tc001(String uid,String mobile) 
  {
	  System.out.println(uid+"   "+mobile);
  }

  @DataProvider
  public Object[][] userdata() 
  {
    return new Object[][] 
    {
      new Object[] {"aakash","9030244444"  },
      new Object[] {"shanthi","8798797898"  },
      new Object[] {"hari","6798787878"  },
      new Object[] {"anil","5798787878"  },
    };
  }
  
  
  
  
  @DataProvider  //Static declaration allows to access outside the class
  public static Object[][] ProdcutInfo() 
  {
    return new Object[][] 
    {
      new Object[] {"Iphone",55000.00,1},
      new Object[] {"Samsung",50000.00,2},
      new Object[] {"Vivo",23000.00,4 },
      new Object[] {"Oneplus",40000.00,3},
    };
  }
  
  
  @DataProvider  //Static declaration allows to access outside the class
  public static String[][] info() 
  {
	  String data[][]= {
			  				{"A","one"},
			  				{"B","two"},
	  					};
	  return data;
  }
  
  
  
}

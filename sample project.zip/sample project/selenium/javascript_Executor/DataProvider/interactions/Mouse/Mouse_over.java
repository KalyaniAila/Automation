package interactions.Mouse;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Mouse_over 
{

	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://naukri.com");
		driver.manage().window().maximize();
		
		
		WebElement Tools_main_menu=driver.findElement(By.xpath("//a[@href='https://insights.naukri.com/careertools'][contains(.,'Tools')]"));
		
		//Perform mouse hover action on selected element
		new Actions(driver).moveToElement(Tools_main_menu).perform();
		
		WebElement SubMenu_Skill_Trends=driver.findElement(By.xpath("//a[@title='Skills Trends']"));
		new Actions(driver).click(SubMenu_Skill_Trends).perform();
		
		
		
	}

}

package framework.Testng.DataProvider;

import org.testng.annotations.Test;

public class Run_DataProvider
{
	
			
	@Test(dataProvider="ProdcutInfo",dataProviderClass=SampleData.class)
	public void TestProduct(String Productname,Double price,int quantity)
	{
		System.out.println(Productname+"   "+price+"   "+quantity);
	}

}

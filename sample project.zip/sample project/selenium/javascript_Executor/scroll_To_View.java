package javascript_Executor;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class scroll_To_View
{

	public static void main(String[] args) throws Exception 
	{
		//Set Runtime environment variable for chrome driver
		System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");    
		//browser initiation command
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com/r.php");
		driver.manage().window().maximize();
		
		
		WebElement Month_dropdown=driver.findElement(By.id("month"));
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();",Month_dropdown);
		
		
		
	
		
	    
	}

}

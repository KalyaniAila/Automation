package javascript_Executor;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Asynchronized_Timeout_to_manage {

	public static void main(String[] args) {
		
		
		//Set Runtime environment variable for chrome driver
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");    
		//browser initiation command
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();
		
		
		WebElement Messenger=driver.findElement(By.linkText("Messenger"));
		Messenger.click();
		
		long start = System.currentTimeMillis();
		
			//Manage timeout all asychronized objects to load webpag.
		   ((JavascriptExecutor) driver).executeAsyncScript(
		       "window.setTimeout(arguments[arguments.length - 1], 500);");
		
		long End=System.currentTimeMillis();
		System.out.println(End-start+"  --> Elapsed time is ");
		
		
		

	}

}

package javascript_Executor;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Action_Commands_Using_JS 
{

	public static void main(String[] args) throws Exception 
	{
		
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");    
		//browser initiation command
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com/r.php");
		driver.manage().window().maximize();
		
		
		//Enable Javascript on automation browser
		JavascriptExecutor js=((JavascriptExecutor)driver);
		
		//Type text into editbox using javascript.
		WebElement Firstname=driver.findElement(By.name("firstname"));
		js.executeScript("arguments[0].value='Newuser'",Firstname);
	
		//Type Text into Editbox using javascript
		WebElement Surname=driver.findElement(By.xpath("//input[@aria-label='Surname']"));
		js.executeScript("arguments[0].value='Anilk'", Surname);
		
		
		//select dropdown with value property using javascript 
		js.executeScript("document.getElementById('day').value='5'");
		
		//select dropdown with Index number  using javascript
		js.executeScript("document.getElementById('month').selectedIndex ='6'");
		
		
		//Select Radio button using javascript
		WebElement Female_radio_btn=driver.findElement(By.xpath("//input[@type='radio'][@value='1']"));
		js.executeScript("arguments[0].click()", Female_radio_btn);
		Thread.sleep(3000);
		
		//Select Radio button using javascript
		WebElement male_radio_btn=driver.findElement(By.xpath("//input[@type='radio'][@value='2']"));
		js.executeScript("arguments[0].checked='checked'", male_radio_btn);
		
		
		
		
	}

}

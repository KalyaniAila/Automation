package javascript_Executor;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Scroll_Browser_Window {

	public static void main(String[] args) {
		
		//Set Runtime environment variable for chrome driver
		System.setProperty("webdriver.chrome.driver", "drivers\\chromedriver.exe");    
		//browser initiation command
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.naukri.com");
		driver.manage().window().maximize();
		
		
		//Scroll Window Down Vertically
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0,1200)");
		
		
		
		/*
		 *  window.scrollBy(0, 100);  // Scroll 100px downwards
		 *  window.scrollBy(100, 0);  // Scroll 100px to the right
		 */
		
		
		
		
		
		
		
		

	}

}

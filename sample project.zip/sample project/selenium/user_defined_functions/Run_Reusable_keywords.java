package user_defined_functions;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.FB_REG;

public class Run_Reusable_keywords extends Reusable_keywords
{
	
	String url="https://www.facebook.com/r.php";
	FB_REG fbpage;
	
  @BeforeClass
  public void beforeclass()
  {
	  Launch_Browser("chrome");
	  Load_Webpage(url);
	  manage_explicitwait(30); 
	  fbpage=new FB_REG(driver);
  }
  
  @Test
  public void User_Reg()
  {
	 Type_text_into_Editbox(fbpage.Firstname_txt, "Newuser");
	 Type_text_into_Editbox(fbpage.Surname_txt, "Webdriver");
	 Type_text_into_Editbox(fbpage.Email_txt, "Newuserwebdriver@gmail.com");
	 
	 select_dropdown("visibletext", fbpage.Dropdownn_Day, "23");
	 select_dropdown("value", fbpage.Dropdownn_month, "10");
	 select_dropdown("index", fbpage.Dropdownn_year, "24");
	 
	 Click_Element("clickable", fbpage.male_rbtn);
	 
  }

}

package user_defined_functions;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.events.WebDriverEventListener;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Reusable_keywords 
{
	
	WebDriver driver=null;
	String driverpath="drivers//";
	WebDriverWait wait;
	
	
	
	
	/*
	 * Keywordname:-->
	 * 			This method brings current class driver references to
	 * 			other class.
	 */
	public WebDriver getDriver()
	{
		return this.driver;
	}
	
	
	
	
	
	
	/*
	 * Keywordname:-->   Launch any browser [chrome,firefox,edge]
	 * Author:-->SunilReddy
	 * ParemetersDefined:-->  Local Parameters
	 */
	public WebDriver Launch_Browser(String browsername)
	{
		
		switch (browsername) 
		{
		
		case "chrome":
			System.setProperty("webdriver.chrome.driver", driverpath+"chromedriver.exe");
			driver=new ChromeDriver();
			break;
			
		case "firefox":
			System.setProperty("webdriver.gecko.driver", driverpath+"geckodriver.exe");
			driver=new FirefoxDriver();
			break;
			
		case "edge":
			System.setProperty("webdriver.edge.driver", driverpath+"edgedriver.exe");
			driver=new EdgeDriver();
			break;

		default:System.out.println("browsername mismatch");
			break;
		}
		
		return driver;
		
	}
	
	
	
	/*
	 * Keywodname:-->   Load webpage to browser window [http:// or htts://]
	 * Author:-->SunilReddy
	 * ParemetersDefined:-->  Local Parameters
	 */
	public void Load_Webpage(String url)
	{
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
	}
	
	
	
	/*
	 * Keywodname:-->   manage explicit wait
	 * Author:-->SunilReddy
	 * ParemetersDefined:-->  Local Parameters
	 */
	public void manage_explicitwait(Integer time_in_sec)
	{
		wait=new WebDriverWait(driver, time_in_sec);
	}
	
	
	/*
	 * Keywodname:-->   Wait for Object using beehaviour [visble,clickable]
	 * Author:-->SunilReddy
	 * ParemetersDefined:-->  Local Parameters
	 */
	public WebElement wait_for_element(String status, WebElement Element)
	{
		WebElement return_element = null;
		
		switch (status) {
		
		case "visible":
				return_element=wait.until(ExpectedConditions.visibilityOf(Element));
			break;
			
		case "clickable":
			return_element=wait.until(ExpectedConditions.elementToBeClickable(Element));
			break;
		
			
		default:System.out.println("Status mismatch");
			break;
		}
		
		return return_element;
		
	}
	
	
	/*
	 * Keywodname:-->  Wait for visible
	 * Author:-->SunilReddy
	 * ParemetersDefined:-->  Local Parameters
	 */
	public WebElement wait_for_visible(WebElement element)
	{
		try {
			return wait.until(ExpectedConditions.visibilityOf(element));
			
		} catch (Exception e) {
			return null;
		}
	}
	
	
	
	
	/*
	 * Keywodname:-->   Type text into editbox..
	 * Author:-->SunilReddy
	 * ParemetersDefined:-->  Local Parameters
	 */
	public void Type_text_into_Editbox(WebElement element, String inputdata)
	{
		try {
			WebElement Selected_Element=wait_for_visible(element);
			Selected_Element.clear();
			Selected_Element.sendKeys(inputdata);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		
	}
	

	
	/*
	 * KeywordName:--> Select Dropdown[POM keyword]
	 * Author:-->
	 * CratedOn:-->
	 * ReviewdBy:-->
	 * LastUdpated Date:-->
	 * Parameters Used:-->
	 */
	public void select_dropdown(String typeofselect,WebElement element,String inputvalue)
	{
		switch (typeofselect) {
		case "visibletext":
			new Select(wait_for_visible(element))
			.selectByVisibleText(inputvalue);
			break;
			
		case "value":
			new Select(wait_for_visible(element))
			.selectByValue(inputvalue);
			break;
			
		case "index":
			
			new Select(wait_for_visible(element))
			.selectByIndex(Integer.valueOf(inputvalue));
			break;

		default:System.out.println("select type mismatch");
			break;
		}
	}
	
	
	
	/*
	 * KeywordName:--> [POM]Click button,link,radiobutton,checkbox,listofitems ---etc
	 * Author:-->
	 * CratedOn:-->
	 * ReviewdBy:-->
	 * LastUdpated Date:-->
	 * Parameters Used:-->
	 */
	public void Click_Element(String status,WebElement element)
	{
		try {
			wait_for_element(status, element).click();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	 /*
	 * KeywordName:--> Mousehover on element.[POM framework]
	 * Author:-->
	 * CreatedOn;-->
	 * ReviewedBy:-->
	 * Parameters used:--> Local
	 * LastUpdationDate:-->
	 */	 
	 public void mousehover(WebElement element)
	 {
			WebElement Hover_element=wait_for_visible(element);
			new Actions(driver).moveToElement(Hover_element).pause(2000).perform();
	 } 
	

	 /*
	 * KeywordName:--> Fileupload using robot class
	 * Author:-->
	 * CreatedOn;-->
	 * ReviewedBy:-->
	 * Parameters used:--> Local
	 * LastUpdationDate:-->
	 */	 
	 public void FileUploading(String filepath)
	 {
	 	String text=filepath;
		//Select String
		StringSelection Stext=new StringSelection(text);
		//Get default system clipboard
		Clipboard clipboard=Toolkit.getDefaultToolkit().getSystemClipboard();
		//set content to clipboard at runtime.
		clipboard.setContents(Stext, Stext);
		
		
		//Crate object for Robot class
		Robot robot=null;
		try {
			robot = new Robot();
		} catch (AWTException e) {
			e.printStackTrace();
		}
		robot.setAutoDelay(1000);
				
		//Press Ctrl+V to paste copied text into notepad file
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
				
		//Press enter key
		robot.keyPress(KeyEvent.VK_ENTER);
				
		//Release Control key
		robot.keyRelease(KeyEvent.VK_CONTROL);

	 }	 
		 
		 
		 
		 /*
		 * KeywordName:--> CaptureScreen using [Filename]
		 * Author:-->
		 * CreatedOn;-->
		 * ReviewedBy:-->
		 * Parameters used:--> Local
		 * LastUpdationDate:-->
		 */	 
		 public void capturescreen(String imagename)
		 {
			try {
				Thread.sleep(5000);
				//creating simple date format
				SimpleDateFormat df=new SimpleDateFormat("yyyy/MMM/dd/ hh-mm-ss");
				//get system default date
				Date d=new Date();
				//Convert system date using default format
				String time=df.format(d);
				
				File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
				FileUtils.copyFile(src, new File("screens\\"+time+imagename+".png"));
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		 }
		 
			 
		 /*
		 * KeywordName:--> SwitchTo window
		 * Author:-->
		 * CreatedOn;-->
		 * ReviewedBy:-->
		 * Parameters used:--> Local
		 * LastUpdationDate:-->
		 */	 
		 public void switchto_window(String Exp_windowtitle)
		 {
			 	//Get All dynamic window ID's
			 	Set<String> Allwindow_IDS=driver.getWindowHandles();
			
				//Iteate for all window times
				for (String EachWindowID : Allwindow_IDS) 
				{
					//Switch to Every window
					driver.switchTo().window(EachWindowID);
					//Capture every window title
					String Runtime_title=driver.getTitle();
					
					//Condition to accept on expected window title match
					if(Runtime_title.contains(Exp_windowtitle))
					{
						break;   //Stop Iteration and get execution control out of for loop.
					}
				  }		
			}
		 
		 
		 
		 /*
		 * KeywordName:--> Select Firstrow and Click link inside first cell
		 * Author:-->
		 * CreatedOn;-->
		 * ReviewedBy:-->
		 * Parameters used:--> Local
		 * LastUpdationDate:-->
		 */	 
		 public void Click_FirstRow_Link_At_Table(String table_xpath)
		 {
			 	WebElement table=driver.findElement(By.xpath(table_xpath));
			 	table.findElements(By.tagName("tr"))
			 	.get(0)
			 	.findElements(By.tagName("td"))
			 	.get(0)
			 	.findElement(By.tagName("a")).click();
		 }
	
	
	
	
	
	public static void main(String args[])
	{
		
		Reusable_keywords keywords=new Reusable_keywords();
		keywords.Launch_Browser("chrome");
		keywords.Load_Webpage("https://www.facebook.com/reg/?rs=7");
		keywords.manage_explicitwait(20);
		
		
		
	
		
	}
	
	
	
	

}

package user_defined_functions;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.Naukri_Menu_Buttons;

public class Run_for_Hover_action extends Reusable_keywords
{
	
	String url="https://www.naukri.com/";
	Naukri_Menu_Buttons menu;
	
  @BeforeClass
  public void beforeclass()
  {
	  Launch_Browser("chrome");
	  Load_Webpage(url);
	  manage_explicitwait(30); 
	  menu=new Naukri_Menu_Buttons(driver);
  }
  
  
  
  @Test
  public void Tc001() 
  {
	  mousehover(menu.MainMenu_jobs);
	  wait_for_visible(menu.Jobs_Search_jobs).click();
	  
  }
  
  
  
}

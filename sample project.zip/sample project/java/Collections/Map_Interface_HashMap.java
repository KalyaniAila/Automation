package corejava.Collections;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Map_Interface_HashMap {

	public static void main(String[] args) 
	{
		
		/*
		 * 1. Map Store pair objects only with in a key and value format
		 * 2. Map is sorted list of set it doesn't accept duplicate and
		 * 3. Unorder collection 	
		 * 4. Hasmap accept one null value..		
		 */
		
		
		Map<Integer, String> map=new HashMap<Integer,String>();
		map.put(103, "Samsung");
		map.put(104, "OnePlus");
		map.put(105, "Vivo");
		map.put(106, "Iphone");
		map.put(107, "Oppo");
		
		
		
		/*
		 * To retrieve data from collection.
		 */
		String value=map.get(105);
		System.out.println(value);
		
		
		
		//Read all hashmap values using foreach loop
		Set<Integer> keys=map.keySet();
		for (Integer keyname : keys) 
		{
			System.out.println(map.get(keyname));
		}
		
		
		
		
		
		
		
		

	}

}

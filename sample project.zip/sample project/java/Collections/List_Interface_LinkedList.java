package corejava.Collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class List_Interface_LinkedList {

	public static void main(String[] args) {
		
		
		List<String> list=new LinkedList<String>();
		list.add("one");
		list.add("two");
		list.add("three");
		list.add("four");
		list.add("five");
		list.add("three");
		
		
		
		/*
		 * Because list accept collection of object inorder. List
		 * allow any single object to retrieve using it's index number.
		 * 
		 * 			Note:--> get(index num) 
		 */
		String obj=list.get(3);
		System.out.println(obj);
		
		
		
		//Remove object from collection
		list.remove("two");
		
		
		//Get objects count
		int count=list.size();
		System.out.println("object count is ---> "+count);
		
		
		//Verify object contains at collection
		boolean flag=list.contains("two");
		System.out.println("Object available status is --> "+flag);
		
		//Read First iterator value
		String itr=list.iterator().next();
		System.out.println("Next iterator value at collection ---> "+itr);
		
		//Verify Collection emtpy status
		boolean flag1=list.isEmpty();
		System.out.println("Is collection is empty ?--> "+flag1);
		
		//Clear all objects at collection
		//list.clear();
		
		
		
		/*
		 * Exmaple:--> Read all list interface collection of obejcts
		 * 				using forloop.
		 */
		for (int i = 0; i < list.size(); i++) 
		{
			String eachobj=list.get(i);
			System.out.println(eachobj);
		}
		
		
		//Read all collection objects using foreach loop
		for (String eachobj : list) {
			System.out.println(eachobj);
		}
		
		
		//Read all object using iterator class
		Iterator<String> tokens=list.iterator();
		//Use while loop to iterate until it has last iteration
		while(tokens.hasNext()) 
		{
			String value=tokens.next();
			System.out.println("=> "+value);
		}
		

	}

}

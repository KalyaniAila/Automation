package corejava.Collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Set_Interface_TreeSet {

	public static void main(String[] args) {
		
		
		//Store objects in random order...
		Set<String> set=new HashSet<String>();
		set.add("one");
		set.add("two");
		set.add("three");
		set.add("four");
		set.add("five");
		set.add("three");
		
		
		//Remove object from collection
		set.remove("two");
		
		
		//Get objects count
		int count=set.size();
		System.out.println("object count is ---> "+count);
		
		
		//Verify object contains at collection
		boolean flag=set.contains("two");
		System.out.println("Object available status is --> "+flag);
		
		//Read First iterator value
		String itr=set.iterator().next();
		System.out.println("Next iterator value at collection ---> "+itr);
		
		//Verify Collection emtpy status
		boolean flag1=set.isEmpty();
		System.out.println("Is collection is empty ?--> "+flag1);
		
		//Clear all objects at collection
		//set.clear();
		
		
		//Read all collection objects using foreach loop
		for (String eachobj : set) 
		{
			System.out.println("# "+eachobj);
		}
		
		
		
		//Read all object using iterator class
		Iterator<String> tokens=set.iterator();
		//Use while loop to iterate until it has last iteration
		while(tokens.hasNext()) 
		{
			String value=tokens.next();
			System.out.println("=> "+value);
		}
		
		
		

	}

}

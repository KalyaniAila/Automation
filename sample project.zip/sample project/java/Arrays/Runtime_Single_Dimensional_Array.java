package corejava.Arrays;

public class Runtime_Single_Dimensional_Array {

	public static void main(String[] args) 
	{
		
		
		String mobiles[]={"Iphone","LG","Vivo","Samsung","BlacBerry","Oppo"};
		System.out.println("Get Second index value is -->"+mobiles[2]);
		System.out.println("Count is --> "+mobiles.length);
		
		int num[]={100,200,300,400,500,600};
		System.out.println("3rd index value is ---> "+num[3]);
		System.out.println("Numbers count is ---> "+num.length);
		
		
		//Print all mobiles
		for (int i = 0; i < mobiles.length; i++) 
		{
			System.out.println(mobiles[i]);
		}
		
		
	}

}

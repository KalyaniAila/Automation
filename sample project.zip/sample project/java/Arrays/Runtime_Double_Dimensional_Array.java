package corejava.Arrays;

public class Runtime_Double_Dimensional_Array {

	public static void main(String[] args) 
	{
	
		
		String userdata[][]={
								{"Arjun","9030248855"},
								{"Harish","854124522"},
								{"Deepak","0989899809"},
							};
		
		System.out.println(userdata[1][0]);  //Deepak
		
		
		//Combination values to store [Strings,numbers,decimalvalues ---etc]
		Object product_info[][]={
									{10012,"Iphone",35000.00},
									{10013,"Samsung",34000.00},
								};
		
		System.out.println(product_info[0][0].getClass());
	}

}

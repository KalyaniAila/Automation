package corejava.Arrays;

public class Static_Array_Single_Dimension 
{

	public static void main(String[] args) 
	{
		
		
		String mobiles[]=new String[5];
		mobiles[0]="Iphone";
		mobiles[1]="LG";
		mobiles[2]="OnePlus";
		mobiles[3]="Samsung";
		mobiles[4]="BlackBerry";

		
		System.out.println(mobiles[3]);
		
		//Get size of an array
		System.out.println(mobiles.length);
		

	}

}

package corejava.Arrays;

public class Static_Double_Dimension_Array {

	public static void main(String[] args) 
	{
		
		/*
		 * Syntax:-->
		 * 		new String[rows][cells];
		 */
		String data[][]=new String[3][2];
		
		//first row data
		data[0][0]="userA";
		data[0][1]="PwdA";
		
		//Second row data
		data[1][0]="userB";
		data[1][1]="PwdB";
		
		
		//Third row data
		data[2][0]="userC";
		data[2][1]="PwdC";
		
		System.out.println(data[1][0]);
		
		//Get Size of array
		System.out.println("Number of rows data available is --->"+data.length);
	}

}

package oops.abstart;

public class Cat extends Animal
{

	public static void main(String[] args) 
	{
		Cat obj=new Cat();
		obj.animalsound();
	
	}

	@Override
	void animalsound() {
		System.out.println("Cat is saying meow---");
		
	}

}

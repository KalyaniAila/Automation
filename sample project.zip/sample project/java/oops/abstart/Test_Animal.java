package oops.abstart;

public class Test_Animal {

	public static void main(String[] args) 
	{
		
		
		Animal obj=new Animal() 
		{
			
			@Override
			void animalsound() 
			{
				System.out.println("hiiiiiii");
				
			}
		};

		
		
		obj.sleep();
	}

}

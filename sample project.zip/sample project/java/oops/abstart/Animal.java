package oops.abstart;

abstract class Animal 
{
	
	Animal()            
	{
		System.out.println("Info starts");
	}
	
	abstract void animalsound();
	
	void sleep()
	{
		System.out.println("sleeeeeep");
	};
	


}

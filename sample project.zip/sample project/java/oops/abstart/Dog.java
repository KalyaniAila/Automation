package oops.abstart;

public class Dog extends Animal 
{
	
	
	

	public static void main(String[] args) 
	{
		Dog obj=new Dog();
		obj.animalsound();
		obj.sleep();

	}

	@Override
	void animalsound() 
	{
		System.out.println("dog is barking");
		
	}

}

package oops.Inheritance;

public class Parent 
{
	
	String name="MQ";
	
	public void method1()
	{
		System.out.println("Method1 from Parent class");
	}

}

package oops.Encapsulation;

public class Encaps 
{
	
	private String name;
	private String email;
	private String mobile;
	public String EmpId="EMP001";
	
	public String getName() 
	{
		System.out.println("Name Retrieved --> "+name);
		return name;
	}
	
	public void setName(String name) 
	{
		System.out.println("Name Initiated -> "+name);
		this.name = name;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getMobile() {
		return mobile;
	}
	
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	
	

}

package oops.Encapsulation;

public class Run_Encapsulation {

	public static void main(String[] args) 
	{
		
		Encaps obj=new Encaps();
		
		//Calling public variable and change value at runtime
		obj.EmpId="MQE003";
		System.out.println(obj.EmpId);
		
		
		//Calling setter and getter methods
		obj.setName("vijay");
		String rname=obj.getName();
		System.out.println(rname);
		
		//Calling Setter and getter methods
		obj.setEmail("info.vijay@gmail.com");
		String remail=obj.getEmail();
		System.out.println(remail);
		

	}

}

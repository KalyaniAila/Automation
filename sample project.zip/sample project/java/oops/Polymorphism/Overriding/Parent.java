package oops.Polymorphism.Overriding;

public class Parent
{
	
	void run(int km)
	{
		System.out.println("parent run method is --> "+km);
	}


}

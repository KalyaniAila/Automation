package oops.Polymorphism.Overriding;

public class ChildA extends Parent
{
	@Override
	void run(int km)    
	{
		System.out.println("Child A run method executed-> "+km);
	}
	
	
	public static void main(String args[])
	{
		
		Parent obj=new ChildA();
		obj.run(10);
		
	}

}

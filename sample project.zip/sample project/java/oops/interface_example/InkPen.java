package oops.interface_example;

public interface InkPen 
{

	
	String pen_color="blue";     //By default satic and final
	
	void fill_ink();             //By default abstarct and final

}

package oops.interface_example;

public interface Pen_Body 
{
	
	String bodyname="circle";
	
	void Body_Design();

}

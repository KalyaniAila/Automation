package oops.interface_example;

public class MakePenBody implements InkPen,Pen_Body
{
	

	public static void main(String[] args) 
	{
		
		System.out.println(pen_color);
		System.out.println(bodyname);

	}

	@Override
	public void Body_Design() {
		System.out.println("Body disign competed");
		
	}

	@Override
	public void fill_ink() 
	{
		System.out.println("ink filling");
		
	}

}

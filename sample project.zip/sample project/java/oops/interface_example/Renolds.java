package oops.interface_example;

public class Renolds implements InkPen
{

	@Override
	public void fill_ink() 
	{
		System.out.println("ink filling completed for renolds");
		
	}
	
	
	public static void main(String args[])
	{
		
		InkPen obj=new Renolds();
		obj.fill_ink();
		
	}
	
	

}
